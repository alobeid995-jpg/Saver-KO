package com.khalid.mediasaver

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * Opens a web page, watches the network requests while the page plays,
 * and remembers the address of the video / live stream so the app can record it.
 */
class BrowserActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var info: TextView
    private lateinit var startBtn: Button

    private var pageUrl: String = ""
    private var best: String? = null
    private var bestRank = 0

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pageUrl = intent.getStringExtra("url") ?: ""

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.parseColor("#0F0F14"))

        info = TextView(this)
        info.setTextColor(Color.WHITE)
        info.textSize = 14f
        info.setPadding(24, 24, 24, 24)
        info.text = "Loading the page... If a video or live stream is on the page, press play. " +
            "You can log in here if the site asks. Tap Start when a stream is found."

        webView = WebView(this)

        val buttons = LinearLayout(this)
        buttons.orientation = LinearLayout.HORIZONTAL
        buttons.setPadding(16, 16, 16, 16)

        val cancelBtn = Button(this)
        cancelBtn.text = "Cancel"
        cancelBtn.setOnClickListener {
            setResult(RESULT_CANCELED)
            finish()
        }

        startBtn = Button(this)
        startBtn.text = "Start"
        startBtn.isEnabled = false
        startBtn.setOnClickListener { finishWithResult() }

        buttons.addView(cancelBtn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        buttons.addView(startBtn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 2f))

        root.addView(info, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        root.addView(webView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(buttons, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        setContentView(root)

        val s = webView.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW

        val cm = CookieManager.getInstance()
        cm.setAcceptCookie(true)
        cm.setAcceptThirdPartyCookies(webView, true)

        webView.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?
            ): WebResourceResponse? {
                val u = request?.url?.toString()
                if (u != null) consider(u)
                return null
            }
        }
        webView.loadUrl(pageUrl)
    }

    private fun consider(address: String) {
        val low = address.lowercase()
        val rank = when {
            low.contains(".m3u8") -> 3
            low.contains(".flv") -> 2
            low.contains(".mpd") -> 2
            low.contains(".mp4") && !low.contains("thumb") && !low.contains("preview") -> 1
            else -> 0
        }
        if (rank == 0) return
        if (rank > bestRank) {
            best = address
            bestRank = rank
            val kind = when (rank) {
                3 -> "HLS (m3u8)"
                2 -> "stream"
                else -> "video file"
            }
            runOnUiThread {
                info.text = "Found a $kind. Tap Start to record or download it."
                startBtn.isEnabled = true
            }
        }
    }

    private fun finishWithResult() {
        val media = best ?: return
        val page = webView.url ?: pageUrl
        val cm = CookieManager.getInstance()
        val cookies = cm.getCookie(media) ?: cm.getCookie(page) ?: ""
        val data = Intent()
        data.putExtra("media", media)
        data.putExtra("referer", page)
        data.putExtra("ua", webView.settings.userAgentString ?: "")
        data.putExtra("cookies", cookies)
        setResult(RESULT_OK, data)
        finish()
    }

    override fun onDestroy() {
        try {
            webView.stopLoading()
            webView.destroy()
        } catch (e: Exception) {
            // ignore
        }
        super.onDestroy()
    }
}
