package com.khalid.mediasaver

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

/**
 * KO Feed: Instagram's own website inside a KO frame.
 * You log in on Instagram's real page; the KO Save button stores what you are looking at.
 */
class InstagramActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var saveBtn: TextView
    private lateinit var statusText: TextView
    private lateinit var loading: ProgressBar

    @Volatile private var busy = false
    @Volatile private var uaString = ""
    @Volatile private var lastPage = ""
    @Volatile private var engineReady = false
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    @Volatile private var apiCallback: ((List<String>, String?) -> Unit)? = null

    private val home = "https://www.instagram.com/"
    private val myData = "https://accountscenter.instagram.com/info_and_permissions/dyi/"

    private val pickFiles =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val cb = fileCallback
            fileCallback = null
            cb?.onReceiveValue(
                WebChromeClient.FileChooserParams.parseResult(
                    if (result.resultCode == Activity.RESULT_OK) Activity.RESULT_OK else Activity.RESULT_CANCELED,
                    result.data
                )
            )
        }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Engine for saving (safe to call again if Media Saver already started it)
        thread {
            try {
                YoutubeDL.getInstance().init(applicationContext)
                FFmpeg.getInstance().init(applicationContext)
                engineReady = true
            } catch (e: Throwable) {
                engineReady = false
            }
        }

        val bg = Color.parseColor("#0F0F14")
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(bg)

        // ---- KO top bar ----
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(dp(14), dp(8), dp(10), dp(8))
        bar.setBackgroundColor(bg)

        val ko = TextView(this)
        ko.text = "KO"
        ko.textSize = 26f
        ko.setTypeface(ko.typeface, android.graphics.Typeface.BOLD)
        ko.setTextColor(Color.parseColor("#7C3AED"))
        ko.post {
            ko.paint.shader = LinearGradient(
                0f, 0f, ko.width.toFloat(), 0f,
                Color.parseColor("#7C3AED"), Color.parseColor("#EC4899"), Shader.TileMode.CLAMP
            )
            ko.invalidate()
        }

        val title = TextView(this)
        title.text = "  Feed"
        title.textSize = 18f
        title.setTextColor(Color.WHITE)

        val spacer = View(this)

        val homeBtn = chip("Home") { webView.loadUrl(home) }
        val dataBtn = chip("My data") {
            webView.loadUrl(myData)
            show("Instagram's official 'Download your information': pick your account, choose what to include (posts, reels, stories, messages) and request the file.")
        }

        val logo = android.widget.ImageView(this)
        logo.setImageResource(R.drawable.logo_feed)
        logo.contentDescription = "KO Feed"
        bar.addView(logo, LinearLayout.LayoutParams(dp(40), dp(40)))
        bar.addView(title)
        bar.addView(spacer, LinearLayout.LayoutParams(0, 1, 1f))
        val logBtn = chip("Errors") { ErrorLog.export(this) }
        logBtn.setOnLongClickListener {
            ErrorLog.clear(this)
            show("Error log cleared", 3000)
            true
        }
        bar.addView(homeBtn)
        bar.addView(dataBtn)
        bar.addView(logBtn)

        // thin KO accent line
        val accent = View(this)
        accent.background = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(Color.parseColor("#7C3AED"), Color.parseColor("#EC4899"))
        )

        // ---- content: Instagram + floating Save ----
        val content = FrameLayout(this)
        webView = WebView(this)
        content.addView(webView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        loading = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        loading.isIndeterminate = true
        loading.visibility = View.GONE
        val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(4))
        lp.gravity = Gravity.TOP
        content.addView(loading, lp)

        statusText = TextView(this)
        statusText.setTextColor(Color.WHITE)
        statusText.textSize = 13f
        statusText.setPadding(dp(12), dp(8), dp(12), dp(8))
        val sbg = GradientDrawable()
        sbg.cornerRadius = dp(12).toFloat()
        sbg.setColor(Color.parseColor("#E61A1A22"))
        statusText.background = sbg
        statusText.visibility = View.GONE
        val slp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        slp.gravity = Gravity.BOTTOM
        slp.setMargins(dp(12), 0, dp(12), dp(132))
        content.addView(statusText, slp)

        saveBtn = TextView(this)
        saveBtn.text = "⬇  Save"
        saveBtn.textSize = 16f
        saveBtn.setTypeface(saveBtn.typeface, android.graphics.Typeface.BOLD)
        saveBtn.setTextColor(Color.WHITE)
        saveBtn.gravity = Gravity.CENTER
        saveBtn.setPadding(dp(20), dp(12), dp(20), dp(12))
        val fab = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(Color.parseColor("#7C3AED"), Color.parseColor("#EC4899"))
        )
        fab.cornerRadius = dp(28).toFloat()
        saveBtn.background = fab
        saveBtn.elevation = dp(6).toFloat()
        saveBtn.setOnClickListener { onSave() }
        val flp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        flp.gravity = Gravity.BOTTOM or Gravity.END
        flp.setMargins(0, 0, dp(16), dp(76))
        content.addView(saveBtn, flp)

        root.addView(bar, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        root.addView(accent, ViewGroup.LayoutParams.MATCH_PARENT, dp(2))
        root.addView(content, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        // ---- web settings ----
        val s = webView.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        s.allowFileAccess = false
        s.setSupportMultipleWindows(false)
        // Look like normal mobile Chrome so Instagram shows its full site
        s.userAgentString = (s.userAgentString ?: "")
            .replace("; wv", "")
            .replace(Regex("Version/\\d+\\.\\d+ "), "")
        uaString = s.userAgentString ?: ""

        val cm = CookieManager.getInstance()
        cm.setAcceptCookie(true)
        cm.setAcceptThirdPartyCookies(webView, true)

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val scheme = request?.url?.scheme?.lowercase() ?: return false
                return scheme != "http" && scheme != "https"
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                loading.visibility = View.GONE
                CookieManager.getInstance().flush()
            }
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView?,
                callback: ValueCallback<Array<Uri>>?,
                params: FileChooserParams?
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                return try {
                    val intent = params?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).setType("*/*")
                    pickFiles.launch(intent)
                    true
                } catch (e: Exception) {
                    fileCallback = null
                    false
                }
            }

            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                loading.visibility = if (newProgress < 100) View.VISIBLE else View.GONE
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        webView.addJavascriptInterface(SaveBridge(), "KOSave")
        if (savedInstanceState != null) webView.restoreState(savedInstanceState) else webView.loadUrl(home)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        webView.saveState(outState)
    }

    private fun chip(label: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.setTextColor(Color.WHITE)
        t.textSize = 13f
        t.setPadding(dp(12), dp(6), dp(12), dp(6))
        val d = GradientDrawable()
        d.cornerRadius = dp(14).toFloat()
        d.setColor(Color.parseColor("#1A1A22"))
        d.setStroke(dp(1), Color.parseColor("#2A2A35"))
        t.background = d
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.setMargins(dp(6), 0, 0, 0)
        t.layoutParams = lp
        t.setOnClickListener { onClick() }
        return t
    }

    private fun show(msg: String, autoHideMs: Long = 0) {
        runOnUiThread {
            statusText.text = msg
            statusText.visibility = View.VISIBLE
            if (autoHideMs > 0) {
                statusText.postDelayed({ if (!busy) statusText.visibility = View.GONE }, autoHideMs)
            }
        }
    }

    // ---------------- Save ----------------

    private fun canonical(address: String): String? {
        val m = Regex("instagram\\.com/(?:[^/?#]+/)?(p|reel|reels|tv)/([A-Za-z0-9_-]+)").find(address)
        if (m != null) {
            val type = if (m.groupValues[1] == "reels") "reel" else m.groupValues[1]
            return "https://www.instagram.com/$type/${m.groupValues[2]}/"
        }
        val st = Regex("instagram\\.com/stories/([^/?#]+)(?:/(\\d+))?").find(address)
        if (st != null) {
            val id = st.groupValues[2]
            return if (id.isNotEmpty()) {
                "https://www.instagram.com/stories/${st.groupValues[1]}/$id/"
            } else {
                "https://www.instagram.com/stories/${st.groupValues[1]}/"
            }
        }
        return null
    }

    private fun onSave() {
        if (busy) return
        val here = webView.url ?: ""
        val direct = canonical(here)
        if (direct != null) {
            startSave(direct, null)
            return
        }
        // In the feed: find the post that fills most of the screen
        val js = "(function(){try{var vh=innerHeight,vw=innerWidth;function vis(e){var r=e.getBoundingClientRect();" +
            "var w=Math.max(0,Math.min(r.right,vw)-Math.max(r.left,0));var h=Math.max(0,Math.min(r.bottom,vh)-Math.max(r.top,0));return w*h;}" +
            "var best=null,ba=0;document.querySelectorAll('article').forEach(function(a){var v=vis(a);if(v>ba){ba=v;best=a;}});" +
            "var link=null;if(best){var as=best.querySelectorAll('a[href]');for(var i=0;i<as.length;i++){var h=as[i].getAttribute('href');" +
            "if(/\\/(p|reel|tv)\\//.test(h)){link=h;break;}}}" +
            "var img=null,ia=0;document.querySelectorAll('img').forEach(function(e){var v=vis(e);if(v>ia&&e.naturalWidth>=300){ia=v;" +
            "var s=e.currentSrc||e.src;if(e.srcset){var c=e.srcset.split(',').map(function(x){x=x.trim().split(' ');return {u:x[0],w:parseInt(x[1])||0};})" +
            ".sort(function(a,b){return b.w-a.w;});if(c.length)s=c[0].u;}img=s;}});" +
            "return JSON.stringify({link:link,img:img});}catch(e){return '{}';}})()"
        webView.evaluateJavascript(js) { raw ->
            var link: String? = null
            var img: String? = null
            try {
                val text = org.json.JSONTokener(raw ?: "\"{}\"").nextValue() as? String ?: "{}"
                val o = org.json.JSONObject(text)
                if (!o.isNull("link")) link = o.optString("link")
                if (!o.isNull("img")) img = o.optString("img")
            } catch (e: Exception) {
                // ignore
            }
            val l = link
            val target = if (l != null && l.isNotEmpty()) canonical(URL(URL(home), l).toString()) else null
            if (target != null) {
                startSave(target, img)
            } else if (img != null && img.startsWith("http")) {
                startSave(null, img)
            } else {
                show("Open the post, reel or story itself (tap it), then tap Save.", 5000)
            }
        }
    }

    /** Netscape cookie file from this page's Instagram login, for the engine. */
    private fun writeCookies(): File {
        val cm = CookieManager.getInstance()
        cm.flush()
        val raw = cm.getCookie("https://www.instagram.com/") ?: ""
        val sb = StringBuilder("# Netscape HTTP Cookie File\n")
        for (part in raw.split(";")) {
            val kv = part.trim()
            val i = kv.indexOf('=')
            if (i > 0) {
                sb.append(".instagram.com\tTRUE\t/\tTRUE\t2147483647\t")
                    .append(kv.substring(0, i)).append("\t").append(kv.substring(i + 1)).append("\n")
            }
        }
        val f = File(filesDir, "cookies.txt")
        f.writeText(sb.toString())
        return f
    }

    // ---- Instagram's own web API, called from inside the logged-in page ----

    inner class SaveBridge {
        @JavascriptInterface
        fun result(json: String?) {
            val list = ArrayList<String>()
            try {
                val a = org.json.JSONArray(json ?: "[]")
                for (i in 0 until a.length()) list.add(a.getString(i))
            } catch (e: Exception) {
                // ignore
            }
            val cb = apiCallback
            apiCallback = null
            cb?.invoke(list, if (list.isEmpty()) "Instagram returned no media for this one" else null)
        }

        @JavascriptInterface
        fun log(msg: String?) {
            ErrorLog.note(this@InstagramActivity, "KO Feed", msg ?: "")
        }

        @JavascriptInterface
        fun fail(msg: String?) {
            val cb = apiCallback
            apiCallback = null
            cb?.invoke(emptyList(), msg ?: "error")
        }
    }

    private fun apiJs(path: String): String {
        val q = org.json.JSONObject.quote(path)
        return "(async function(){try{" +
            "var P=" + q + ";var H={'X-IG-App-ID':'936619743392459','X-Requested-With':'XMLHttpRequest'};" +
            "function L(m){try{KOSave.log(String(m));}catch(e){}}" +
            "var out=[];function area(x){return (x.width||0)*(x.height||0);}" +
            "function best(it){if(it.video_versions&&it.video_versions.length){return it.video_versions.slice().sort(function(a,b){return area(b)-area(a);})[0].url;}" +
            "var c=((it.image_versions2&&it.image_versions2.candidates)||[]).slice().sort(function(a,b){return area(b)-area(a);});return c.length?c[0].url:null;}" +
            "function add(it){if(it.carousel_media&&it.carousel_media.length){it.carousel_media.forEach(function(x){var u=best(x);if(u)out.push(u);});}else{var u=best(it);if(u)out.push(u);}}" +
            "async function J(u){var r=await fetch(u,{headers:H,credentials:'include'});L(u.split('?')[0]+' -> HTTP '+r.status);" +
            "if(!r.ok){var t='';try{t=(await r.text()).substring(0,200);}catch(e){}throw new Error('HTTP '+r.status+' from '+u.split('?')[0]+' '+t);}return await r.json();}" +
            "function dom(){var vh=innerHeight,vw=innerWidth,b=null,ba=0;document.querySelectorAll('video,img').forEach(function(e){var r=e.getBoundingClientRect();" +
            "var w=Math.max(0,Math.min(r.right,vw)-Math.max(r.left,0)),h=Math.max(0,Math.min(r.bottom,vh)-Math.max(r.top,0));if(w*h>ba){" +
            "var s=e.currentSrc||e.src||'';if(e.tagName=='IMG'&&e.srcset){var c=e.srcset.split(',').map(function(x){x=x.trim().split(' ');return {u:x[0],w:parseInt(x[1])||0};})" +
            ".sort(function(a,b){return b.w-a.w;});if(c.length)s=c[0].u;}if(s.indexOf('http')==0){ba=w*h;b=s;}}});if(b){L('Using what is on screen: '+b.substring(0,80));out.push(b);}}" +
            "L('Save on '+P);" +
            "var hl=P.match(/\\/stories\\/highlights\\/(\\d+)/);var st=P.match(/\\/stories\\/([^\\/]+)\\/?(\\d+)?/);" +
            "var po=P.match(/\\/(p|reel|reels|tv)\\/([A-Za-z0-9_-]+)/);" +
            "if(hl){try{var j=await J('/api/v1/feed/reels_media/?reel_ids=highlight:'+hl[1]);" +
            "var rl=(j.reels&&j.reels['highlight:'+hl[1]])||(j.reels_media&&j.reels_media[0]);((rl&&rl.items)||[]).forEach(add);}catch(e){L(e.message);}}" +
            "else if(st){" +
            "if(st[2]){try{var jm=await J('/api/v1/media/'+st[2]+'/info/');(jm.items||[]).forEach(add);}catch(e){L(e.message);}}" +
            "if(!out.length){try{var pj=await J('/api/v1/users/web_profile_info/?username='+encodeURIComponent(st[1]));var uid=pj.data.user.id;" +
            "var j2=await J('/api/v1/feed/reels_media/?reel_ids='+uid);var rl2=(j2.reels&&j2.reels[uid])||(j2.reels_media&&j2.reels_media[0]);" +
            "var items=(rl2&&rl2.items)||[];L('story items: '+items.length);var pick=items.filter(function(i){return st[2]&&String(i.pk)===st[2];});" +
            "(pick.length?pick:items).forEach(add);}catch(e){L(e.message);}}}" +
            "else if(po){try{var sc=po[2].substring(0,11);var A='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_';" +
            "var n=BigInt(0);for(var i=0;i<sc.length;i++){n=n*BigInt(64)+BigInt(A.indexOf(sc[i]));}" +
            "var j3=await J('/api/v1/media/'+n.toString()+'/info/');(j3.items||[]).forEach(add);}catch(e){L(e.message);}}" +
            "if(!out.length)dom();" +
            "L('found '+out.length+' file(s)');" +
            "KOSave.result(JSON.stringify(out));}catch(e){KOSave.fail(String(e&&e.message||e));}})();"
    }

    /** Asks Instagram (from inside the page) for the media addresses of a post / reel / story. */
    private fun callApi(link: String, cb: (List<String>, String?) -> Unit) {
        val path = try {
            URL(link).path
        } catch (e: Exception) {
            link
        }
        runOnUiThread {
            apiCallback = cb
            webView.evaluateJavascript(apiJs(path), null)
            webView.postDelayed({
                if (apiCallback === cb) {
                    apiCallback = null
                    cb(emptyList(), "Instagram did not answer in time")
                }
            }, 25000)
        }
    }

    /** Downloads the media files the API returned and saves them. */
    private fun downloadAll(urls: List<String>): Int {
        var saved = 0
        val dir = File(cacheDir, "ig_api")
        dir.deleteRecursively()
        dir.mkdirs()
        for ((i, u) in urls.withIndex()) {
            try {
                val c = URL(u).openConnection() as HttpURLConnection
                c.setRequestProperty("User-Agent", uaString)
                c.setRequestProperty("Referer", home)
                c.connectTimeout = 15000
                c.readTimeout = 60000
                if (c.responseCode !in 200..299) {
                    c.disconnect()
                    continue
                }
                val type = (c.contentType ?: "").lowercase()
                val pathExt = URL(u).path.substringAfterLast('.', "").lowercase()
                val ext = when {
                    type.contains("mp4") || pathExt == "mp4" -> "mp4"
                    type.contains("webp") || pathExt == "webp" -> "webp"
                    type.contains("heic") || pathExt == "heic" -> "heic"
                    type.contains("png") || pathExt == "png" -> "png"
                    else -> "jpg"
                }
                val f = File(dir, "ig_" + System.currentTimeMillis() + "_" + i + "." + ext)
                c.inputStream.use { inp -> f.outputStream().use { o -> inp.copyTo(o) } }
                c.disconnect()
                if (f.length() > 0 && Saver.save(this, f)) saved++
                f.delete()
            } catch (e: Throwable) {
                // skip this one
            }
        }
        dir.deleteRecursively()
        return saved
    }

    private fun finish(msg: String) {
        if (msg.startsWith("Could not")) {
            ErrorLog.error(this, "KO Feed", "Page: " + lastPage + "\n" + msg)
        }
        busy = false
        runOnUiThread { saveBtn.alpha = 1f }
        show(msg, 6000)
    }

    private fun doneMessage(saved: Int, error: String?): String =
        if (saved > 0) {
            "Saved $saved file(s) to MediaSaver (Pictures / Movies)."
        } else {
            if (error != null) ErrorLog.note(this, "KO Feed", "Full error: " + error)
            val short = (error ?: "nothing found to save").lines().lastOrNull { it.isNotBlank() } ?: ""
            "Could not save this one. " + short.take(200)
        }

    private fun waitEngine() {
        var tries = 0
        while (!engineReady && tries < 60) {
            Thread.sleep(500)
            tries++
        }
    }

    private fun startSave(link: String?, fallbackImg: String?) {
        lastPage = (webView.url ?: "") + (if (link != null) "  (saving " + link + ")" else "")
        busy = true
        saveBtn.alpha = 0.5f
        show("Saving in the best quality...")

        if (link != null && link.contains("/stories/")) {
            // Stories: Instagram's own API first (works with your login), engine second
            callApi(link) { urls, apiErr ->
                thread {
                    var saved = downloadAll(urls)
                    var err = apiErr
                    if (saved == 0) {
                        try {
                            waitEngine()
                            saved = saveWithEngine(link, writeCookies())
                        } catch (e: Throwable) {
                            if (err == null) err = e.message
                        }
                    }
                    finish(doneMessage(saved, err))
                }
            }
            return
        }

        thread {
            var saved = 0
            var err: String? = null
            if (link != null) {
                try {
                    waitEngine()
                    saved = saveWithEngine(link, writeCookies())
                } catch (e: Throwable) {
                    err = e.message ?: e.toString()
                }
            }
            if (saved > 0 || link == null) {
                if (saved == 0 && fallbackImg != null && saveImage(fallbackImg)) saved = 1
                finish(doneMessage(saved, err))
            } else {
                // Posts / reels / photos the engine couldn't take: ask Instagram directly
                show("Trying another way...")
                callApi(link) { urls, apiErr ->
                    thread {
                        var s2 = downloadAll(urls)
                        if (s2 == 0 && fallbackImg != null && saveImage(fallbackImg)) s2 = 1
                        finish(doneMessage(s2, apiErr ?: err))
                    }
                }
            }
        }
    }

    /** Videos in best quality, then photos (and carousel photos) as full-size images. */
    private fun saveWithEngine(link: String, cookies: File): Int {
        val outDir = File(cacheDir, "ig")
        outDir.deleteRecursively()
        outDir.mkdirs()
        val picDir = File(cacheDir, "ig_pics")
        picDir.deleteRecursively()
        picDir.mkdirs()
        var lastError: Throwable? = null

        val r1 = YoutubeDLRequest(link)
        r1.addOption("-o", outDir.absolutePath + "/%(id)s.%(ext)s")
        r1.addOption("--no-mtime")
        r1.addOption("-i")
        r1.addOption("--playlist-end", "50")
        r1.addOption("-f", "bv*+ba/b")
        r1.addOption("-S", "res,vcodec:h264,br,acodec:aac")
        r1.addOption("--merge-output-format", "mp4")
        r1.addOption("--cookies", cookies.absolutePath)
        try {
            YoutubeDL.getInstance().execute(r1, "ig")
        } catch (e: Throwable) {
            lastError = e
        }

        val r2 = YoutubeDLRequest(link)
        r2.addOption("-o", picDir.absolutePath + "/%(id)s.%(ext)s")
        r2.addOption("-i")
        r2.addOption("--playlist-end", "50")
        r2.addOption("--skip-download")
        r2.addOption("--write-thumbnail")
        r2.addOption("--ignore-no-formats-error")
        r2.addOption("--cookies", cookies.absolutePath)
        try {
            YoutubeDL.getInstance().execute(r2, "ig")
        } catch (e: Throwable) {
            if (lastError == null) lastError = e
        }

        val videos = (outDir.listFiles() ?: emptyArray<File>())
            .filter { it.isFile && it.length() > 0 && !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") }
        val videoIds = videos.map { it.nameWithoutExtension }.toSet()
        val pics = (picDir.listFiles() ?: emptyArray<File>())
            .filter { it.isFile && it.length() > 0 && it.nameWithoutExtension !in videoIds }

        var saved = 0
        for (f in videos + pics) {
            if (Saver.save(this, f)) saved++
        }
        outDir.deleteRecursively()
        picDir.deleteRecursively()
        if (saved == 0 && lastError != null) throw lastError
        return saved
    }

    private fun saveImage(address: String): Boolean {
        return try {
            val c = URL(address).openConnection() as HttpURLConnection
            c.setRequestProperty("User-Agent", uaString)
            c.setRequestProperty("Referer", home)
            val ck = CookieManager.getInstance().getCookie(address)
            if (!ck.isNullOrEmpty()) c.setRequestProperty("Cookie", ck)
            c.connectTimeout = 15000
            c.readTimeout = 30000
            if (c.responseCode !in 200..299) {
                c.disconnect()
                return false
            }
            val bytes = c.inputStream.use { it.readBytes() }
            c.disconnect()
            val ext = when {
                bytes.size > 3 && bytes[0] == 0xFF.toByte() && bytes[1] == 0xD8.toByte() -> "jpg"
                bytes.size > 3 && bytes[0] == 0x89.toByte() && bytes[1] == 0x50.toByte() -> "png"
                bytes.size > 12 && String(bytes, 8, 4, Charsets.ISO_8859_1) == "WEBP" -> "webp"
                else -> "jpg"
            }
            val f = File(cacheDir, "ig_photo_" + System.currentTimeMillis() + "." + ext)
            f.writeBytes(bytes)
            val ok = Saver.save(this, f)
            f.delete()
            ok
        } catch (e: Throwable) {
            false
        }
    }

    override fun onDestroy() {
        try {
            webView.stopLoading()
            webView.destroy()
        } catch (e: Exception) {
            // ignore
        }
        super.onDestroy()
    }
}
