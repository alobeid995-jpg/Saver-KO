package com.khalid.mediasaver

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Opens a web page, watches the network requests while the page plays,
 * and remembers the address of the video / live stream so the app can record it.
 */
class BrowserActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private lateinit var info: TextView
    private lateinit var startBtn: Button

    private var pageUrl: String = ""
    private var photoMode = false

    // Extra stream detection for players that hide their requests (TikTok live)
    private val handler = Handler(Looper.getMainLooper())
    private var probes = 0
    @Volatile private var roomChecked = false
    @Volatile private var nativeLookupRunning = false
    private val probeRunnable = object : Runnable {
        override fun run() {
            probe()
            probes += 1
            if (probes < 60 && !isFinishing) handler.postDelayed(this, 3000)
        }
    }
    private var best: String? = null
    private var bestRank = 0
    private var bestHeaders: Map<String, String> = emptyMap()

    // "Record in page" mode: copy every video piece the page loads while it plays
    private lateinit var recBtn: Button
    @Volatile private var recording = false
    private var recOut: FileOutputStream? = null
    private var recFile: File? = null
    private var recExec: ExecutorService = Executors.newSingleThreadExecutor()
    private val seen = java.util.Collections.synchronizedSet(HashSet<String>())
    @Volatile private var recSegs = 0
    @Volatile private var recBytes = 0L
    @Volatile private var recErrors = 0
    @Volatile private var recLastError = ""
    @Volatile private var uaString = ""
    private val segRegex = Regex("\\.(ts|m4s|m4v|cmfv|fmp4)(\\?|$)", RegexOption.IGNORE_CASE)
    private val initRegex = Regex("init[^/]*\\.mp4", RegexOption.IGNORE_CASE)

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        pageUrl = intent.getStringExtra("url") ?: ""
        photoMode = intent.getBooleanExtra("photos", false)

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.parseColor("#0F0F14"))

        info = TextView(this)
        info.setTextColor(Color.WHITE)
        info.textSize = 14f
        info.setPadding(24, 24, 24, 24)
        info.text = "Loading the page... If a video or live stream is on the page, press play. " +
            "You can log in here if the site asks. Tap Start when a stream is found."

        webView = WebView(this)

        val buttons = LinearLayout(this)
        buttons.orientation = LinearLayout.HORIZONTAL
        buttons.setPadding(16, 16, 16, 16)

        val cancelBtn = Button(this)
        cancelBtn.text = "Cancel"
        cancelBtn.setOnClickListener {
            setResult(RESULT_CANCELED)
            finish()
        }

        startBtn = Button(this)
        startBtn.text = "Start"
        startBtn.isEnabled = false
        startBtn.setOnClickListener { if (photoMode) finishWithPhotos() else finishWithResult() }

        buttons.addView(cancelBtn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        buttons.addView(startBtn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 2f))

        recBtn = Button(this)
        recBtn.text = "Record in page"
        recBtn.setOnClickListener { if (!recording) startRec() else stopRec() }
        buttons.addView(recBtn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 2f))
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        if (photoMode) {
            recBtn.visibility = View.GONE
            startBtn.text = "Save photos"
            startBtn.isEnabled = true
            info.text = "Photo mode: scroll the page so the photos you want are loaded, " +
                "then tap Save photos. You can log in here if the site asks."
        }

        root.addView(info, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        root.addView(webView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(buttons, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        setContentView(root)

        val s = webView.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.mediaPlaybackRequiresUserGesture = false
        s.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        // Desktop browser identity, so sites don't push you to "install our app"
        s.userAgentString =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) " +
                "Chrome/124.0.0.0 Safari/537.36"
        uaString = s.userAgentString

        val cm = CookieManager.getInstance()
        cm.setAcceptCookie(true)
        cm.setAcceptThirdPartyCookies(webView, true)

        webView.webViewClient = object : WebViewClient() {
            // Ignore attempts to jump to other apps (intent://, market://, tango://...)
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val scheme = request?.url?.scheme?.lowercase() ?: return false
                return scheme != "http" && scheme != "https"
            }

            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?
            ): WebResourceResponse? {
                val u = request?.url?.toString()
                val h: Map<String, String> = request?.requestHeaders ?: emptyMap()
                if (u != null) {
                    consider(u, h)
                    if (recording && request?.method == "GET") maybeRecord(u, h)
                }
                return null
            }
        }
        webView.addJavascriptInterface(Bridge(), "KOBridge")
        if (!photoMode) handler.postDelayed(probeRunnable, 3000)
        webView.loadUrl(pageUrl)
    }

    private fun consider(address: String, headers: Map<String, String>) {
        val low = address.lowercase()
        val rank = when {
            low.contains(".m3u8") -> 3
            low.contains(".flv") -> 2
            low.contains(".mpd") -> 2
            low.contains(".mp4") && !low.contains("thumb") && !low.contains("preview") -> 1
            else -> 0
        }
        if (rank == 0) return
        if (address == best) return
        if (rank >= bestRank) {
            best = address
            bestRank = rank
            bestHeaders = headers
            val host = android.net.Uri.parse(address).host ?: ""
            val kind = when (rank) {
                3 -> "HLS (m3u8)"
                2 -> "stream"
                else -> "video file"
            }
            runOnUiThread {
                info.text = "Found a $kind from $host (${android.net.Uri.parse(address).lastPathSegment ?: ""}). Tap Start to record or download it."
                startBtn.isEnabled = true
            }
        }
    }

    private fun probe() {
        // 1) Any stream the page's own player has loaded
        val js = "(function(){try{var o=[];performance.getEntriesByType('resource').forEach(function(e){" +
            "var n=e.name;if(/\\.(m3u8|flv)(\\?|$)/i.test(n))o.push(n);});return JSON.stringify(o);}catch(e){return '[]';}})()"
        webView.evaluateJavascript(js) { raw -> handleJsList(raw) }

        // 2) TikTok: ask TikTok's live-room API from inside the page (same login, passes the bot check)
        val pageNow = webView.url ?: pageUrl
        val here = pageNow.lowercase()

        // 3) TikTok: the same direct lookup the Live mode uses, with this page's login cookies
        if (here.contains("tiktok.com") && best == null && !nativeLookupRunning && probes % 3 == 0) {
            nativeLookupRunning = true
            val cookie = CookieManager.getInstance().getCookie("https://www.tiktok.com/") ?: ""
            Thread {
                try {
                    val lk = StreamFinder.tiktokLookup(pageNow, cookie, uaString)
                    val pick = StreamFinder.firstWorking(lk.candidates, uaString, "https://www.tiktok.com/")
                    val u = pick.first
                    if (u != null) {
                        consider(u, emptyMap())
                    } else {
                        runOnUiThread {
                            if (best == null && !recording) {
                                info.text = "Looking for the stream... (" + lk.note + "; " + pick.second + ")"
                            }
                        }
                    }
                } catch (e: Throwable) {
                    // try again on the next round
                }
                nativeLookupRunning = false
            }.start()
        }

        if (here.contains("tiktok.com") && bestRank < 3 && probes % 2 == 0) {
            val tjs = "(function(){try{var h=document.documentElement.innerHTML;" +
                "var r=h.match(/\"roomId\":\"(\\d{6,})\"/);if(r)KOBridge.room(r[1]);" +
                "var m=location.pathname.match(/@([^/?#]+)/);if(!m)return 'nouser';" +
                "fetch('/api-live/user/room/?aid=1988&sourceType=54&uniqueId='+encodeURIComponent(m[1]),{credentials:'include'})" +
                ".then(function(x){return x.text();}).then(function(t){KOBridge.text(t);}).catch(function(e){});" +
                "return 'ok';}catch(e){return 'err';}})()"
            webView.evaluateJavascript(tjs, null)
        }
    }

    private fun handleJsList(raw: String?) {
        try {
            val text = org.json.JSONTokener(raw ?: "\"[]\"").nextValue() as? String ?: return
            val arr = org.json.JSONArray(text)
            val list = ArrayList<String>()
            for (i in 0 until arr.length()) list.add(arr.getString(i))
            val u = StreamFinder.best(list)
            if (u != null) consider(u, emptyMap())
        } catch (e: Exception) {
            // ignore
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun text(t: String?) {
            val body = t ?: return
            val u = StreamFinder.best(StreamFinder.urls(body))
            if (u != null) {
                consider(u, emptyMap())
                return
            }
            val rid = StreamFinder.roomId(body)
            if (rid != null) room(rid)
        }

        @JavascriptInterface
        fun room(id: String?) {
            val rid = id ?: return
            if (roomChecked) return
            roomChecked = true
            Thread {
                try {
                    val c = URL("https://webcast.tiktok.com/webcast/room/info/?aid=1988&room_id=" + rid)
                        .openConnection() as HttpURLConnection
                    c.setRequestProperty("User-Agent", uaString)
                    c.setRequestProperty("Referer", "https://www.tiktok.com/")
                    val ck = CookieManager.getInstance().getCookie("https://www.tiktok.com/")
                    if (!ck.isNullOrEmpty()) c.setRequestProperty("Cookie", ck)
                    c.connectTimeout = 15000
                    c.readTimeout = 20000
                    val code = c.responseCode
                    val stream = if (code in 200..299) c.inputStream else c.errorStream
                    val body = stream?.bufferedReader()?.use { it.readText() } ?: ""
                    c.disconnect()
                    val u = StreamFinder.best(StreamFinder.urls(body))
                    if (u != null) consider(u, emptyMap()) else roomChecked = false
                } catch (e: Exception) {
                    roomChecked = false
                }
            }.start()
        }
    }

    private fun maybeRecord(address: String, headers: Map<String, String>) {
        val isPiece = segRegex.containsMatchIn(address) || initRegex.containsMatchIn(address)
        if (!isPiece) return
        if (!seen.add(address)) return
        val copy = HashMap<String, String>(headers)
        try {
            recExec.execute { fetchPiece(address, copy) }
        } catch (e: Exception) {
            // recorder already stopped
        }
    }

    private fun fetchPiece(address: String, headers: Map<String, String>) {
        try {
            val c = URL(address).openConnection() as HttpURLConnection
            c.connectTimeout = 15000
            c.readTimeout = 30000
            c.instanceFollowRedirects = true
            val skip = setOf("host", "connection", "accept-encoding", "range", "content-length", "cookie")
            for ((k, v) in headers) {
                if (k.lowercase() !in skip) c.setRequestProperty(k, v)
            }
            val ck = CookieManager.getInstance().getCookie(address)
            if (!ck.isNullOrEmpty()) c.setRequestProperty("Cookie", ck)
            if (c.getRequestProperty("User-Agent") == null) c.setRequestProperty("User-Agent", uaString)
            if (c.getRequestProperty("Referer") == null) c.setRequestProperty("Referer", pageUrl)
            val code = c.responseCode
            if (code in 200..299) {
                val data = c.inputStream.use { it.readBytes() }
                synchronized(this) { recOut?.write(data) }
                recSegs = recSegs + 1
                recBytes = recBytes + data.size
            } else {
                recErrors = recErrors + 1
                recLastError = "HTTP $code"
            }
            c.disconnect()
        } catch (e: Exception) {
            recErrors = recErrors + 1
            recLastError = e.message ?: "error"
        }
        updateRecInfo()
    }

    private fun updateRecInfo() {
        runOnUiThread {
            if (recording) {
                var t = "Recording from the page: $recSegs pieces, ${recBytes / 1024} KB. " +
                    "Keep this screen open while the live plays. Tap Stop & save when done."
                if (recErrors > 0) t += "\n$recErrors failed (last: $recLastError)"
                info.text = t
            }
        }
    }

    private fun startRec() {
        val b = best
        if (b != null && bestRank == 2 && b.lowercase().contains(".flv")) {
            info.text = "This live comes as one continuous stream, not pieces, so Record in page can't copy it. Tap Start instead."
            return
        }
        try {
            val f = File(cacheDir, "page_rec.bin")
            recOut = FileOutputStream(f)
            recFile = f
        } catch (e: Exception) {
            info.text = "Could not start recording: ${e.message}"
            return
        }
        seen.clear()
        recSegs = 0
        recBytes = 0L
        recErrors = 0
        recLastError = ""
        recExec = Executors.newSingleThreadExecutor()
        recording = true
        recBtn.text = "Stop & save"
        startBtn.isEnabled = false
        info.text = "Recording... waiting for video pieces. Make sure the live is playing in the page."
    }

    private fun stopRec() {
        recording = false
        recBtn.isEnabled = false
        info.text = "Finishing..."
        Thread {
            recExec.shutdown()
            try {
                recExec.awaitTermination(20, TimeUnit.SECONDS)
            } catch (e: Exception) {
                // ignore
            }
            synchronized(this) {
                try {
                    recOut?.close()
                } catch (e: Exception) {
                    // ignore
                }
                recOut = null
            }
            val f = recFile
            runOnUiThread {
                if (f == null || !f.exists() || f.length() == 0L) {
                    info.text = "Nothing was captured ($recErrors failed, last: $recLastError). " +
                        "Make sure the live is playing, then try again."
                    recBtn.text = "Record in page"
                    recBtn.isEnabled = true
                } else {
                    val head = ByteArray(12)
                    try {
                        f.inputStream().use { it.read(head) }
                    } catch (e: Exception) {
                        // ignore
                    }
                    val marker = String(head, 4, 4, Charsets.ISO_8859_1)
                    val ext = if (head[0] == 0x47.toByte()) {
                        "ts"
                    } else if (marker == "ftyp" || marker == "styp" || marker == "moof") {
                        "mp4"
                    } else {
                        "ts"
                    }
                    val named = File(cacheDir, "page_recording_" + System.currentTimeMillis() + "." + ext)
                    f.renameTo(named)
                    val data = Intent()
                    data.putExtra("recorded", named.absolutePath)
                    setResult(RESULT_OK, data)
                    finish()
                }
            }
        }.start()
    }

    private fun finishWithPhotos() {
        startBtn.isEnabled = false
        info.text = "Collecting photos..."
        val js = "(function(){var o=[],s={};document.querySelectorAll('img').forEach(function(i){" +
            "var u=i.currentSrc||i.src;if(u&&u.indexOf('http')==0&&!s[u]&&(i.naturalWidth>=300||i.naturalHeight>=300)){s[u]=1;o.push(u);}});" +
            "return JSON.stringify(o);})()"
        webView.evaluateJavascript(js) { raw ->
            val list = ArrayList<String>()
            try {
                val text = org.json.JSONTokener(raw ?: "\"[]\"").nextValue() as? String ?: "[]"
                val arr = org.json.JSONArray(text)
                for (i in 0 until arr.length()) list.add(arr.getString(i))
            } catch (e: Exception) {
                // leave empty
            }
            val page = webView.url ?: pageUrl
            val cm = CookieManager.getInstance()
            val data = Intent()
            data.putStringArrayListExtra("photoUrls", list)
            data.putExtra("referer", page)
            data.putExtra("ua", uaString)
            data.putExtra("cookies", cm.getCookie(page) ?: "")
            setResult(RESULT_OK, data)
            finish()
        }
    }

    private fun finishWithResult() {
        val media = best ?: return
        val page = webView.url ?: pageUrl
        val cm = CookieManager.getInstance()
        val cookies = cm.getCookie(media) ?: cm.getCookie(page) ?: ""
        val data = Intent()
        data.putExtra("media", media)
        data.putExtra("referer", page)
        data.putExtra("ua", webView.settings.userAgentString ?: "")
        data.putExtra("cookies", cookies)

        // Forward the headers the page itself used for this stream (Origin, Authorization, ...)
        val skip = setOf(
            "host", "connection", "accept-encoding", "range", "user-agent", "cookie",
            "content-length", "referer", "if-none-match", "if-modified-since"
        )
        val list = ArrayList<String>()
        for ((k, v) in bestHeaders) {
            val low = k.lowercase()
            if (low !in skip && !low.startsWith("sec-")) list.add("$k: $v")
        }
        data.putStringArrayListExtra("headers", list)
        setResult(RESULT_OK, data)
        finish()
    }

    override fun onDestroy() {
        handler.removeCallbacks(probeRunnable)
        recording = false
        try {
            recExec.shutdownNow()
            recOut?.close()
        } catch (e: Exception) {
            // ignore
        }
        try {
            webView.stopLoading()
            webView.destroy()
        } catch (e: Exception) {
            // ignore
        }
        super.onDestroy()
    }
}
