package com.khalid.mediasaver

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Build
import android.widget.Toast
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Keeps a running log of errors (and Save / lookup steps) that can be exported as a .txt file. */
object ErrorLog {
    private const val MAX_BYTES = 300_000L

    private fun file(context: Context) = File(context.filesDir, "errors.txt")

    private fun version(context: Context): String = try {
        context.packageManager.getPackageInfo(context.packageName, 0).versionName ?: "?"
    } catch (e: Exception) {
        "?"
    }

    @Synchronized
    private fun write(context: Context, level: String, source: String, message: String) {
        try {
            val f = file(context)
            if (f.exists() && f.length() > MAX_BYTES) {
                // keep the newest half
                val text = f.readText()
                f.writeText(text.substring(text.length / 2))
            }
            val time = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
            f.appendText("[$time] [$level] [$source] v${version(context)}\n${message.trim()}\n\n")
        } catch (e: Exception) {
            // logging must never crash the app
        }
    }

    fun error(context: Context, source: String, message: String) = write(context, "ERROR", source, message)

    fun note(context: Context, source: String, message: String) = write(context, "INFO", source, message)

    fun clear(context: Context) {
        try {
            file(context).delete()
        } catch (e: Exception) {
            // ignore
        }
    }

    /** Saves the log to Downloads/MediaSaver and opens the share sheet. */
    fun export(activity: Activity) {
        val f = file(activity)
        if (!f.exists() || f.length() == 0L) {
            Toast.makeText(activity, "No errors recorded yet", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val stamp = SimpleDateFormat("yyyy-MM-dd_HH-mm", Locale.US).format(Date())
            val out = File(activity.cacheDir, "MediaSaver-errors-$stamp.txt")
            val header = "Media Saver error log\nApp version: ${version(activity)}\n" +
                "Device: ${Build.MANUFACTURER} ${Build.MODEL}, Android ${Build.VERSION.RELEASE}\n\n"
            out.writeText(header + f.readText())
            val uri = Saver.saveUri(activity, out)
            out.delete()
            if (uri == null) {
                Toast.makeText(activity, "Could not save the log", Toast.LENGTH_LONG).show()
                return
            }
            Toast.makeText(activity, "Saved to Downloads/MediaSaver", Toast.LENGTH_LONG).show()
            val send = Intent(Intent.ACTION_SEND)
            send.type = "text/plain"
            send.putExtra(Intent.EXTRA_STREAM, uri)
            send.putExtra(Intent.EXTRA_SUBJECT, "Media Saver error log")
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            activity.startActivity(Intent.createChooser(send, "Share error log"))
        } catch (e: Exception) {
            Toast.makeText(activity, "Could not export: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
