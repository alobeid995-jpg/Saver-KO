package com.khalid.mediasaver

import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import android.webkit.MimeTypeMap
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var urlInput: EditText
    private lateinit var modeGroup: RadioGroup
    private lateinit var downloadBtn: Button
    private lateinit var progress: ProgressBar
    private lateinit var status: TextView

    private var initThread: Thread? = null
    @Volatile private var engineReady = false
    @Volatile private var engineError: String? = null

    private val pickCookies =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri != null) importCookies(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        urlInput = findViewById(R.id.urlInput)
        modeGroup = findViewById(R.id.modeGroup)
        downloadBtn = findViewById(R.id.downloadBtn)
        progress = findViewById(R.id.progress)
        status = findViewById(R.id.status)

        findViewById<Button>(R.id.pasteBtn).setOnClickListener { pasteFromClipboard() }
        downloadBtn.setOnClickListener { startDownload() }
        findViewById<Button>(R.id.updateBtn).setOnClickListener { updateEngine() }
        findViewById<Button>(R.id.cookiesBtn).setOnClickListener {
            pickCookies.launch(arrayOf("*/*"))
        }

        status.text = "Starting engine..."
        initThread = thread {
            try {
                YoutubeDL.getInstance().init(applicationContext)
                FFmpeg.getInstance().init(applicationContext)
                engineReady = true
                runOnUiThread { status.text = "Ready. Paste a link and tap Download." }
            } catch (e: Throwable) {
                engineError = e.message ?: e.toString()
                runOnUiThread { status.text = "Engine failed to start: $engineError" }
            }
        }

        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND) {
            val text = intent.getStringExtra(Intent.EXTRA_TEXT) ?: return
            val link = extractUrl(text) ?: return
            urlInput.setText(link)
            startDownload()
        }
    }

    private fun extractUrl(text: String): String? =
        Regex("https?://\\S+").find(text)?.value?.trimEnd('.', ',', ')', ']')

    private fun pasteFromClipboard() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = cm.primaryClip
        val text = if (clip != null && clip.itemCount > 0) {
            clip.getItemAt(0).coerceToText(this)?.toString()
        } else null
        if (text.isNullOrBlank()) {
            Toast.makeText(this, "Clipboard is empty", Toast.LENGTH_SHORT).show()
        } else {
            urlInput.setText(extractUrl(text) ?: text.trim())
        }
    }

    private fun setBusy(busy: Boolean, message: String) {
        downloadBtn.isEnabled = !busy
        progress.visibility = if (busy) View.VISIBLE else View.GONE
        status.text = message
    }

    private fun startSnapDownload(raw: String) {
        val user = Regex("snapchat\\.com/add/([A-Za-z0-9._-]+)").find(raw)?.groupValues?.get(1)
            ?: raw.trim().removePrefix("@").trim()
        if (!Regex("[A-Za-z0-9._-]{3,30}").matches(user)) {
            Toast.makeText(this, "Type a Snapchat username, like name123", Toast.LENGTH_SHORT).show()
            return
        }
        setBusy(true, "Looking for the public story of @$user ...")

        thread {
            val outDir = File(cacheDir, "snap")
            val message: String = try {
                outDir.deleteRecursively()
                outDir.mkdirs()

                val page = httpGetText("https://www.snapchat.com/add/$user")
                val urls = Regex("\"mediaUrl\"\\s*:\\s*\"(https:[^\"]+)\"")
                    .findAll(page)
                    .map { unescapeJson(it.groupValues[1]) }
                    .distinct()
                    .toList()
                if (urls.isEmpty()) {
                    throw IllegalStateException(
                        "No public story found for @$user. The account may be private, or have no active story right now."
                    )
                }

                var saved = 0
                urls.forEachIndexed { i, address ->
                    val f = downloadToFile(address, File(outDir, user + "_" + (i + 1)))
                    if (f != null && saveToMediaStore(f)) saved++
                }
                if (saved == 0) {
                    throw IllegalStateException("Found the story but could not download the files.")
                }
                "Done. Saved $saved snap(s) from @$user in the MediaSaver folder (Pictures / Movies)."
            } catch (e: Throwable) {
                "Failed: ${e.message ?: e.toString()}"
            } finally {
                outDir.deleteRecursively()
            }
            runOnUiThread { setBusy(false, message) }
        }
    }

    private val browserAgent =
        "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

    private fun httpGetText(address: String): String {
        val conn = URL(address).openConnection() as HttpURLConnection
        conn.setRequestProperty("User-Agent", browserAgent)
        conn.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
        conn.connectTimeout = 20000
        conn.readTimeout = 30000
        try {
            val code = conn.responseCode
            if (code == 404) throw IllegalStateException("That Snapchat profile was not found.")
            if (code !in 200..299) throw IllegalStateException("Snapchat answered with code $code. Try again later.")
            return conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    private fun unescapeJson(s: String): String =
        s.replace("\\u002F", "/")
            .replace("\\u0026", "&")
            .replace("\\u003D", "=")
            .replace("\\/", "/")

    private fun downloadToFile(address: String, base: File): File? {
        val conn = URL(address).openConnection() as HttpURLConnection
        conn.setRequestProperty("User-Agent", browserAgent)
        conn.connectTimeout = 20000
        conn.readTimeout = 60000
        return try {
            if (conn.responseCode !in 200..299) return null
            val tmp = File(base.parentFile, base.name + ".bin")
            conn.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }

            val head = ByteArray(12)
            tmp.inputStream().use { it.read(head) }
            val type = (conn.contentType ?: "").lowercase()
            val ext = when {
                head[4] == 'f'.code.toByte() && head[5] == 't'.code.toByte() &&
                    head[6] == 'y'.code.toByte() && head[7] == 'p'.code.toByte() -> "mp4"
                head[0] == 0xFF.toByte() && head[1] == 0xD8.toByte() -> "jpg"
                head[0] == 0x89.toByte() && head[1] == 'P'.code.toByte() -> "png"
                head[0] == 'R'.code.toByte() && head[8] == 'W'.code.toByte() -> "webp"
                "video" in type -> "mp4"
                else -> "jpg"
            }
            val out = File(base.parentFile, base.name + "." + ext)
            tmp.renameTo(out)
            out
        } catch (e: Exception) {
            null
        } finally {
            conn.disconnect()
        }
    }

    private fun startDownload() {
        if (modeGroup.checkedRadioButtonId == R.id.modeSnap) {
            startSnapDownload(urlInput.text.toString())
            return
        }
        val url = extractUrl(urlInput.text.toString())
        if (url == null) {
            Toast.makeText(this, "Paste a valid link first", Toast.LENGTH_SHORT).show()
            return
        }
        val mode = when (modeGroup.checkedRadioButtonId) {
            R.id.modeAudio -> "audio"
            R.id.modeVideo -> "video"
            else -> "auto"
        }
        setBusy(true, "Downloading... keep the app open.")

        thread {
            initThread?.join()
            val outDir = File(cacheDir, "dl")
            val message: String = try {
                if (!engineReady) {
                    throw IllegalStateException("Engine failed to start: ${engineError ?: "unknown error"}")
                }
                outDir.deleteRecursively()
                outDir.mkdirs()

                val cookies = File(filesDir, "cookies.txt")
                val template = outDir.absolutePath + "/%(id)s.%(ext)s"

                // Pass 1: videos / reels / audio
                val request = YoutubeDLRequest(url)
                request.addOption("-o", template)
                request.addOption("--no-mtime")
                request.addOption("--playlist-end", "50")
                if (mode == "audio") {
                    request.addOption("-f", "bestaudio[ext=m4a]/bestaudio/best")
                } else {
                    request.addOption("-f", "best[ext=mp4]/bestvideo[ext=mp4]+bestaudio[ext=m4a]/best")
                    request.addOption("--merge-output-format", "mp4")
                }
                if (cookies.exists()) {
                    request.addOption("--cookies", cookies.absolutePath)
                }

                var failure: Throwable? = null
                try {
                    YoutubeDL.getInstance().execute(request)
                } catch (e: Throwable) {
                    failure = e
                }

                // Pass 2: photo posts have no video, so save their image instead
                if (failure != null && mode != "audio") {
                    try {
                        val photoRequest = YoutubeDLRequest(url)
                        photoRequest.addOption("-o", template)
                        photoRequest.addOption("--no-mtime")
                        photoRequest.addOption("--playlist-end", "50")
                        photoRequest.addOption("--skip-download")
                        photoRequest.addOption("--write-thumbnail")
                        photoRequest.addOption("--ignore-no-formats-error")
                        if (cookies.exists()) {
                            photoRequest.addOption("--cookies", cookies.absolutePath)
                        }
                        YoutubeDL.getInstance().execute(photoRequest)
                    } catch (e: Throwable) {
                        // keep whatever was saved; the first error is reported if nothing was
                    }
                }

                val imageExts = setOf("jpg", "jpeg", "png", "webp")
                val all = (outDir.listFiles() ?: emptyArray<File>())
                    .filter { it.isFile && !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") }
                // Drop preview images of videos that were already downloaded
                val videoStems = all
                    .filter { it.extension.lowercase() !in imageExts }
                    .map { it.nameWithoutExtension }
                    .toSet()
                val files = all
                    .filter { it.extension.lowercase() !in imageExts || it.nameWithoutExtension !in videoStems }
                    .sortedBy { it.name }

                if (files.isEmpty()) {
                    throw failure ?: IllegalStateException("Nothing was downloaded.")
                }

                var saved = 0
                for (f in files) {
                    if (saveToMediaStore(f)) saved++
                }
                "Done. Saved $saved file(s) in the MediaSaver folder (Pictures / Movies / Music)."
            } catch (e: Throwable) {
                friendlyError(e)
            } finally {
                outDir.deleteRecursively()
            }
            runOnUiThread { setBusy(false, message) }
        }
    }

    private fun friendlyError(e: Throwable): String {
        val raw = (e.message ?: e.toString()).trim()
        val low = raw.lowercase()
        val hint = when {
            "429" in low || "too many requests" in low ->
                "Instagram is limiting requests. Wait a few minutes and try again."
            "login" in low || "cookies" in low || "private" in low || "empty media response" in low ->
                "This content needs a logged-in session. Tap Import login cookies."
            "unsupported url" in low -> "This link type is not supported."
            else -> "If this keeps happening, tap Update engine and try again."
        }
        val short = if (raw.length > 280) raw.take(280) + "..." else raw
        return "Failed: $short\n\n$hint"
    }

    private fun saveToMediaStore(file: File): Boolean {
        val ext = file.extension.lowercase()
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
            ?: "application/octet-stream"

        val target = when {
            mime.startsWith("image/") ->
                MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) to
                    Environment.DIRECTORY_PICTURES
            mime.startsWith("video/") ->
                MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) to
                    Environment.DIRECTORY_MOVIES
            mime.startsWith("audio/") ->
                MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) to
                    Environment.DIRECTORY_MUSIC
            else ->
                MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) to
                    Environment.DIRECTORY_DOWNLOADS
        }

        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, target.second + "/MediaSaver")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }

        val uri = contentResolver.insert(target.first, values) ?: return false
        val out = contentResolver.openOutputStream(uri) ?: return false
        out.use { o -> file.inputStream().use { it.copyTo(o) } }

        val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
        contentResolver.update(uri, done, null, null)
        return true
    }

    private fun updateEngine() {
        setBusy(true, "Updating engine...")
        thread {
            initThread?.join()
            val message = try {
                val result = YoutubeDL.getInstance().updateYoutubeDL(applicationContext)
                "Engine update finished: ${result ?: "done"}"
            } catch (e: Throwable) {
                "Update failed: ${e.message ?: e.toString()}"
            }
            runOnUiThread { setBusy(false, message) }
        }
    }

    private fun importCookies(uri: Uri) {
        try {
            val input = contentResolver.openInputStream(uri)
                ?: throw IllegalStateException("Could not open that file.")
            input.use { i ->
                File(filesDir, "cookies.txt").outputStream().use { o -> i.copyTo(o) }
            }
            status.text = "Login cookies imported. Stories and logged-in content can now work."
        } catch (e: Throwable) {
            status.text = "Could not import cookies: ${e.message ?: e.toString()}"
        }
    }
}
