package com.khalid.mediasaver

import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import android.webkit.MimeTypeMap
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import java.io.File
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var urlInput: EditText
    private lateinit var modeGroup: RadioGroup
    private lateinit var downloadBtn: Button
    private lateinit var progress: ProgressBar
    private lateinit var status: TextView

    private var initThread: Thread? = null
    @Volatile private var engineReady = false
    @Volatile private var engineError: String? = null

    private val pickCookies =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri != null) importCookies(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        urlInput = findViewById(R.id.urlInput)
        modeGroup = findViewById(R.id.modeGroup)
        downloadBtn = findViewById(R.id.downloadBtn)
        progress = findViewById(R.id.progress)
        status = findViewById(R.id.status)

        findViewById<Button>(R.id.pasteBtn).setOnClickListener { pasteFromClipboard() }
        downloadBtn.setOnClickListener { startDownload() }
        findViewById<Button>(R.id.updateBtn).setOnClickListener { updateEngine() }
        findViewById<Button>(R.id.cookiesBtn).setOnClickListener {
            pickCookies.launch(arrayOf("*/*"))
        }

        status.text = "Starting engine..."
        initThread = thread {
            try {
                YoutubeDL.getInstance().init(applicationContext)
                FFmpeg.getInstance().init(applicationContext)
                engineReady = true
                runOnUiThread { status.text = "Ready. Paste a link and tap Download." }
            } catch (e: Throwable) {
                engineError = e.message ?: e.toString()
                runOnUiThread { status.text = "Engine failed to start: $engineError" }
            }
        }

        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND) {
            val text = intent.getStringExtra(Intent.EXTRA_TEXT) ?: return
            val link = extractUrl(text) ?: return
            urlInput.setText(link)
            startDownload()
        }
    }

    private fun extractUrl(text: String): String? =
        Regex("https?://\\S+").find(text)?.value?.trimEnd('.', ',', ')', ']')

    private fun pasteFromClipboard() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = cm.primaryClip
        val text = if (clip != null && clip.itemCount > 0) {
            clip.getItemAt(0).coerceToText(this)?.toString()
        } else null
        if (text.isNullOrBlank()) {
            Toast.makeText(this, "Clipboard is empty", Toast.LENGTH_SHORT).show()
        } else {
            urlInput.setText(extractUrl(text) ?: text.trim())
        }
    }

    private fun setBusy(busy: Boolean, message: String) {
        downloadBtn.isEnabled = !busy
        progress.visibility = if (busy) View.VISIBLE else View.GONE
        status.text = message
    }

    private fun startDownload() {
        val url = extractUrl(urlInput.text.toString())
        if (url == null) {
            Toast.makeText(this, "Paste a valid link first", Toast.LENGTH_SHORT).show()
            return
        }
        val mode = when (modeGroup.checkedRadioButtonId) {
            R.id.modeAudio -> "audio"
            R.id.modeVideo -> "video"
            else -> "auto"
        }
        setBusy(true, "Downloading... keep the app open.")

        thread {
            initThread?.join()
            val outDir = File(cacheDir, "dl")
            val message: String = try {
                if (!engineReady) {
                    throw IllegalStateException("Engine failed to start: ${engineError ?: "unknown error"}")
                }
                outDir.deleteRecursively()
                outDir.mkdirs()

                val cookies = File(filesDir, "cookies.txt")
                val template = outDir.absolutePath + "/%(id)s.%(ext)s"

                // Pass 1: videos / reels / audio
                val request = YoutubeDLRequest(url)
                request.addOption("-o", template)
                request.addOption("--no-mtime")
                request.addOption("--playlist-end", "50")
                if (mode == "audio") {
                    request.addOption("-f", "bestaudio[ext=m4a]/bestaudio/best")
                } else {
                    request.addOption("-f", "best[ext=mp4]/bestvideo[ext=mp4]+bestaudio[ext=m4a]/best")
                    request.addOption("--merge-output-format", "mp4")
                }
                if (cookies.exists()) {
                    request.addOption("--cookies", cookies.absolutePath)
                }

                var failure: Throwable? = null
                try {
                    YoutubeDL.getInstance().execute(request)
                } catch (e: Throwable) {
                    failure = e
                }

                // Pass 2: photo posts have no video, so save their image instead
                if (failure != null && mode != "audio") {
                    try {
                        val photoRequest = YoutubeDLRequest(url)
                        photoRequest.addOption("-o", template)
                        photoRequest.addOption("--no-mtime")
                        photoRequest.addOption("--playlist-end", "50")
                        photoRequest.addOption("--skip-download")
                        photoRequest.addOption("--write-thumbnail")
                        photoRequest.addOption("--ignore-no-formats-error")
                        if (cookies.exists()) {
                            photoRequest.addOption("--cookies", cookies.absolutePath)
                        }
                        YoutubeDL.getInstance().execute(photoRequest)
                    } catch (e: Throwable) {
                        // keep whatever was saved; the first error is reported if nothing was
                    }
                }

                val imageExts = setOf("jpg", "jpeg", "png", "webp")
                val all = (outDir.listFiles() ?: emptyArray<File>())
                    .filter { it.isFile && !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") }
                // Drop preview images of videos that were already downloaded
                val videoStems = all
                    .filter { it.extension.lowercase() !in imageExts }
                    .map { it.nameWithoutExtension }
                    .toSet()
                val files = all
                    .filter { it.extension.lowercase() !in imageExts || it.nameWithoutExtension !in videoStems }
                    .sortedBy { it.name }

                if (files.isEmpty()) {
                    throw failure ?: IllegalStateException("Nothing was downloaded.")
                }

                var saved = 0
                for (f in files) {
                    if (saveToMediaStore(f)) saved++
                }
                "Done. Saved $saved file(s) in the MediaSaver folder (Pictures / Movies / Music)."
            } catch (e: Throwable) {
                friendlyError(e)
            } finally {
                outDir.deleteRecursively()
            }
            runOnUiThread { setBusy(false, message) }
        }
    }

    private fun friendlyError(e: Throwable): String {
        val raw = (e.message ?: e.toString()).trim()
        val low = raw.lowercase()
        val hint = when {
            "429" in low || "too many requests" in low ->
                "Instagram is limiting requests. Wait a few minutes and try again."
            "login" in low || "cookies" in low || "private" in low || "empty media response" in low ->
                "This content needs a logged-in session. Tap Import login cookies."
            "unsupported url" in low -> "This link type is not supported."
            else -> "If this keeps happening, tap Update engine and try again."
        }
        val short = if (raw.length > 280) raw.take(280) + "..." else raw
        return "Failed: $short\n\n$hint"
    }

    private fun saveToMediaStore(file: File): Boolean {
        val ext = file.extension.lowercase()
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
            ?: "application/octet-stream"

        val target = when {
            mime.startsWith("image/") ->
                MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) to
                    Environment.DIRECTORY_PICTURES
            mime.startsWith("video/") ->
                MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) to
                    Environment.DIRECTORY_MOVIES
            mime.startsWith("audio/") ->
                MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) to
                    Environment.DIRECTORY_MUSIC
            else ->
                MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) to
                    Environment.DIRECTORY_DOWNLOADS
        }

        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, target.second + "/MediaSaver")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }

        val uri = contentResolver.insert(target.first, values) ?: return false
        val out = contentResolver.openOutputStream(uri) ?: return false
        out.use { o -> file.inputStream().use { it.copyTo(o) } }

        val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
        contentResolver.update(uri, done, null, null)
        return true
    }

    private fun updateEngine() {
        setBusy(true, "Updating engine...")
        thread {
            initThread?.join()
            val message = try {
                val result = YoutubeDL.getInstance().updateYoutubeDL(applicationContext)
                "Engine update finished: ${result ?: "done"}"
            } catch (e: Throwable) {
                "Update failed: ${e.message ?: e.toString()}"
            }
            runOnUiThread { setBusy(false, message) }
        }
    }

    private fun importCookies(uri: Uri) {
        try {
            val input = contentResolver.openInputStream(uri)
                ?: throw IllegalStateException("Could not open that file.")
            input.use { i ->
                File(filesDir, "cookies.txt").outputStream().use { o -> i.copyTo(o) }
            }
            status.text = "Login cookies imported. Stories and logged-in content can now work."
        } catch (e: Throwable) {
            status.text = "Could not import cookies: ${e.message ?: e.toString()}"
        }
    }
}
