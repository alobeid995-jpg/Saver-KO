package com.khalid.mediasaver

/** Finds live/video stream addresses (m3u8 / flv) inside page text or JSON. */
object StreamFinder {

    private val urlRegex = Regex("https?://[^\"'\\\\\\s<>]+?\\.(?:flv|m3u8)[^\"'\\\\\\s<>]*")
    private val roomRegex = Regex("\"(?:roomId|room_id)\"\\s*:\\s*\"?(\\d{6,})")

    /** Undo the JSON / HTML escaping TikTok uses around URLs. */
    fun clean(text: String): String = text
        .replace("\\\\u0026", "&").replace("\\u0026", "&")
        .replace("\\\\u002F", "/").replace("\\u002F", "/")
        .replace("\\\\/", "/").replace("\\/", "/")
        .replace("&amp;", "&")

    fun urls(text: String): List<String> =
        urlRegex.findAll(clean(text)).map { it.value }.toList().distinct()

    fun roomId(text: String): String? {
        val id = roomRegex.find(text)?.groupValues?.get(1) ?: return null
        return if (id.trim('0').isEmpty()) null else id
    }

    /** HLS first (safe to stop any time), then the best-quality FLV. */
    fun best(found: List<String>): String? {
        if (found.isEmpty()) return null
        return found.maxByOrNull { score(it) }
    }

    private fun score(u: String): Int {
        val l = u.lowercase()
        var s = 0
        if (l.contains(".m3u8")) s += 100
        if (l.contains("_or4") || l.contains("origin") || l.contains("full_hd") || l.contains("uhd")) s += 20
        if (l.contains("_hd")) s += 10
        if (l.contains("_sd")) s -= 5
        if (l.contains("_ld")) s -= 10
        if (l.contains("only_audio") || l.contains("audio_only")) s -= 50
        return s
    }
}
