package com.khalid.mediasaver

import android.Manifest
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.LinearGradient
import android.graphics.Shader
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import android.webkit.MimeTypeMap
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private lateinit var urlInput: EditText
    private lateinit var modeGroup: RadioGroup
    private lateinit var downloadBtn: Button
    private lateinit var progress: ProgressBar
    private lateinit var status: TextView
    private lateinit var liveRow: LinearLayout
    private lateinit var liveMinutes: EditText
    private lateinit var stopBtn: Button
    private lateinit var tabSocial: Button
    private lateinit var tabWeb: Button
    private lateinit var modeScroll: HorizontalScrollView
    private lateinit var webHint: TextView
    private lateinit var webModeGroup: RadioGroup
    private var webTab = false

    @Volatile private var liveActive = false

    private val askNotifications =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { _: Boolean -> }

    private val browserLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val data = result.data
            if (result.resultCode == RESULT_OK && data != null) {
                val photos = data.getStringArrayListExtra("photoUrls")
                if (photos != null) {
                    downloadPhotos(
                        photos,
                        data.getStringExtra("referer") ?: "",
                        data.getStringExtra("ua") ?: "",
                        data.getStringExtra("cookies") ?: ""
                    )
                    return@registerForActivityResult
                }
                val rec = data.getStringExtra("recorded")
                val media = data.getStringExtra("media")
                if (rec != null) {
                    saveRecorded(File(rec))
                } else if (media != null) {
                    startCaptured(
                        media,
                        data.getStringExtra("referer") ?: "",
                        data.getStringExtra("ua") ?: "",
                        data.getStringExtra("cookies") ?: "",
                        data.getStringArrayListExtra("headers") ?: arrayListOf<String>()
                    )
                }
            }
        }

    private var initThread: Thread? = null
    @Volatile private var engineReady = false
    @Volatile private var engineError: String? = null

    private val pickCookies =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
            if (uri != null) importCookies(uri)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        urlInput = findViewById(R.id.urlInput)
        modeGroup = findViewById(R.id.modeGroup)
        downloadBtn = findViewById(R.id.downloadBtn)
        progress = findViewById(R.id.progress)
        status = findViewById(R.id.status)
        liveRow = findViewById(R.id.liveRow)
        liveMinutes = findViewById(R.id.liveMinutes)
        stopBtn = findViewById(R.id.stopBtn)

        tabSocial = findViewById(R.id.tabSocial)
        tabWeb = findViewById(R.id.tabWeb)
        modeScroll = findViewById(R.id.modeScroll)
        webHint = findViewById(R.id.webHint)
        webModeGroup = findViewById(R.id.webModeGroup)
        tabSocial.setOnClickListener { selectTab(false) }
        tabWeb.setOnClickListener { selectTab(true) }
        modeGroup.setOnCheckedChangeListener { _, _ -> updateLiveRow() }
        selectTab(false)
        stopBtn.setOnClickListener {
            stopBtn.isEnabled = false
            status.text = "Stopping and saving what was recorded..."
            thread {
                try {
                    YoutubeDL.getInstance().destroyProcessById("live")
                } catch (e: Throwable) {
                    // the recording thread reports the result
                }
            }
        }

        // Purple -> pink gradient on the big KO signature
        val koLogo = findViewById<TextView>(R.id.koLogo)
        koLogo.post {
            val w = koLogo.paint.measureText(koLogo.text.toString())
            koLogo.paint.shader = LinearGradient(
                0f, 0f, w, 0f,
                intArrayOf(0xFF7C3AED.toInt(), 0xFFEC4899.toInt()),
                null,
                Shader.TileMode.CLAMP
            )
            koLogo.invalidate()
        }

        findViewById<Button>(R.id.pasteBtn).setOnClickListener { pasteFromClipboard() }
        downloadBtn.setOnClickListener { startDownload() }
        findViewById<Button>(R.id.updateBtn).setOnClickListener { updateEngine() }
        findViewById<Button>(R.id.cookiesBtn).setOnClickListener {
            pickCookies.launch(arrayOf("*/*"))
        }

        status.text = "Starting engine..."
        initThread = thread {
            try {
                YoutubeDL.getInstance().init(applicationContext)
                FFmpeg.getInstance().init(applicationContext)
                engineReady = true
                runOnUiThread { status.text = "Ready. Paste a link and tap Download." }
            } catch (e: Throwable) {
                engineError = e.message ?: e.toString()
                runOnUiThread { status.text = "Engine failed to start: $engineError" }
            }
        }

        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun selectTab(web: Boolean) {
        webTab = web
        val on = ColorStateList.valueOf(0xFF7C3AED.toInt())
        val off = ColorStateList.valueOf(0xFF1A1A22.toInt())
        tabSocial.backgroundTintList = if (web) off else on
        tabWeb.backgroundTintList = if (web) on else off
        modeScroll.visibility = if (web) View.GONE else View.VISIBLE
        webHint.visibility = if (web) View.VISIBLE else View.GONE
        webModeGroup.visibility = if (web) View.VISIBLE else View.GONE
        downloadBtn.text = if (web) "Open page" else "Download"
        urlInput.hint =
            if (web) "Paste the page link (Tango, other sites)" else "Paste a link (or a Snapchat username)"
        updateLiveRow()
    }

    private fun updateLiveRow() {
        val show = webTab || modeGroup.checkedRadioButtonId == R.id.modeLive
        liveRow.visibility = if (show) View.VISIBLE else View.GONE
    }

    private fun handleIntent(intent: Intent?) {
        if (intent?.action == Intent.ACTION_SEND) {
            val text = intent.getStringExtra(Intent.EXTRA_TEXT) ?: return
            val link = extractUrl(text) ?: return
            urlInput.setText(link)
            selectTab(false)
            startDownload()
        }
    }

    private fun extractUrl(text: String): String? =
        Regex("https?://\\S+").find(text)?.value?.trimEnd('.', ',', ')', ']')

    private fun pasteFromClipboard() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = cm.primaryClip
        val text = if (clip != null && clip.itemCount > 0) {
            clip.getItemAt(0).coerceToText(this)?.toString()
        } else null
        if (text.isNullOrBlank()) {
            Toast.makeText(this, "Clipboard is empty", Toast.LENGTH_SHORT).show()
        } else {
            urlInput.setText(extractUrl(text) ?: text.trim())
        }
    }

    private fun setBusy(busy: Boolean, message: String) {
        downloadBtn.isEnabled = !busy
        progress.visibility = if (busy) View.VISIBLE else View.GONE
        status.text = message
    }

    private fun startSnapDownload(raw: String) {
        val user = Regex("snapchat\\.com/add/([A-Za-z0-9._-]+)").find(raw)?.groupValues?.get(1)
            ?: raw.trim().removePrefix("@").trim()
        if (!Regex("[A-Za-z0-9._-]{3,30}").matches(user)) {
            Toast.makeText(this, "Type a Snapchat username, like name123", Toast.LENGTH_SHORT).show()
            return
        }
        setBusy(true, "Looking for the public story of @$user ...")

        thread {
            val outDir = File(cacheDir, "snap")
            val message: String = try {
                outDir.deleteRecursively()
                outDir.mkdirs()

                val page = httpGetText("https://www.snapchat.com/add/$user")
                val urls = Regex("\"mediaUrl\"\\s*:\\s*\"(https:[^\"]+)\"")
                    .findAll(page)
                    .map { unescapeJson(it.groupValues[1]) }
                    .distinct()
                    .toList()
                if (urls.isEmpty()) {
                    throw IllegalStateException(
                        "No public story found for @$user. The account may be private, or have no active story right now."
                    )
                }

                var saved = 0
                urls.forEachIndexed { i, address ->
                    val f = downloadToFile(address, File(outDir, user + "_" + (i + 1)))
                    if (f != null && saveToMediaStore(f)) saved++
                }
                if (saved == 0) {
                    throw IllegalStateException("Found the story but could not download the files.")
                }
                "Done. Saved $saved snap(s) from @$user in the MediaSaver folder (Pictures / Movies)."
            } catch (e: Throwable) {
                "Failed: ${e.message ?: e.toString()}"
            } finally {
                outDir.deleteRecursively()
            }
            runOnUiThread { setBusy(false, message) }
        }
    }

    private val browserAgent =
        "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

    private fun httpGetText(address: String): String {
        val conn = URL(address).openConnection() as HttpURLConnection
        conn.setRequestProperty("User-Agent", browserAgent)
        conn.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
        conn.connectTimeout = 20000
        conn.readTimeout = 30000
        try {
            val code = conn.responseCode
            if (code == 404) throw IllegalStateException("That Snapchat profile was not found.")
            if (code !in 200..299) throw IllegalStateException("Snapchat answered with code $code. Try again later.")
            return conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    private fun unescapeJson(s: String): String =
        s.replace("\\u002F", "/")
            .replace("\\u0026", "&")
            .replace("\\u003D", "=")
            .replace("\\/", "/")

    private fun downloadToFile(address: String, base: File): File? {
        val conn = URL(address).openConnection() as HttpURLConnection
        conn.setRequestProperty("User-Agent", browserAgent)
        conn.connectTimeout = 20000
        conn.readTimeout = 60000
        return try {
            if (conn.responseCode !in 200..299) return null
            val tmp = File(base.parentFile, base.name + ".bin")
            conn.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }

            val head = ByteArray(12)
            tmp.inputStream().use { it.read(head) }
            val type = (conn.contentType ?: "").lowercase()
            val ext = when {
                head[4] == 'f'.code.toByte() && head[5] == 't'.code.toByte() &&
                    head[6] == 'y'.code.toByte() && head[7] == 'p'.code.toByte() -> "mp4"
                head[0] == 0xFF.toByte() && head[1] == 0xD8.toByte() -> "jpg"
                head[0] == 0x89.toByte() && head[1] == 'P'.code.toByte() -> "png"
                head[0] == 'R'.code.toByte() && head[8] == 'W'.code.toByte() -> "webp"
                "video" in type -> "mp4"
                else -> "jpg"
            }
            val out = File(base.parentFile, base.name + "." + ext)
            tmp.renameTo(out)
            out
        } catch (e: Exception) {
            null
        } finally {
            conn.disconnect()
        }
    }

    private fun fixExtension(f: File): File {
        val head = ByteArray(8)
        val n = f.inputStream().use { it.read(head) }
        if (n < 8) return f
        val isMp4 = head[4] == 'f'.code.toByte() && head[5] == 't'.code.toByte() &&
            head[6] == 'y'.code.toByte() && head[7] == 'p'.code.toByte()
        val isTs = head[0] == 0x47.toByte()
        val target = when {
            isMp4 -> "mp4"
            isTs -> "ts"
            else -> f.extension
        }
        if (target == f.extension) return f
        val out = File(f.parentFile, f.nameWithoutExtension + "." + target)
        return if (f.renameTo(out)) out else f
    }

    private fun startLive() {
        val url = extractUrl(urlInput.text.toString())
        if (url == null) {
            Toast.makeText(this, "Paste the live link first", Toast.LENGTH_SHORT).show()
            return
        }
        if (liveActive) return
        val minutes = (liveMinutes.text.toString().toIntOrNull() ?: 60).coerceIn(1, 360)
        liveActive = true

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        ContextCompat.startForegroundService(this, Intent(this, RecordingService::class.java))

        stopBtn.isEnabled = true
        stopBtn.visibility = View.VISIBLE
        setBusy(
            true,
            "Recording... it stops when the stream ends, after $minutes minutes, or when you tap Stop. You can leave the app."
        )

        thread {
            initThread?.join()
            val outDir = File(cacheDir, "live")
            val message: String = try {
                if (!engineReady) {
                    throw IllegalStateException("Engine failed to start: ${engineError ?: "unknown error"}")
                }
                outDir.deleteRecursively()
                outDir.mkdirs()

                val request = YoutubeDLRequest(url)
                request.addOption("-o", outDir.absolutePath + "/live_%(id)s_%(epoch)s.%(ext)s")
                request.addOption("--no-mtime")
                request.addOption("--no-part")
                request.addOption("--downloader", "ffmpeg")
                request.addOption("--hls-use-mpegts")
                request.addOption("--downloader-args", "ffmpeg_i:-reconnect 1 -reconnect_streamed 1 -reconnect_at_eof 1 -reconnect_delay_max 10 -rw_timeout 30000000 ffmpeg:-t " + (minutes * 60))
                val cookies = File(filesDir, "cookies.txt")
                if (cookies.exists()) {
                    request.addOption("--cookies", cookies.absolutePath)
                }

                var failure: Throwable? = null
                try {
                    YoutubeDL.getInstance().execute(request, "live")
                } catch (e: Throwable) {
                    failure = e
                }

                val files = (outDir.listFiles() ?: emptyArray<File>())
                    .filter { it.isFile && it.length() > 0 }
                    .map { fixExtension(it) }
                    .sortedBy { it.name }

                if (files.isEmpty()) {
                    throw failure ?: IllegalStateException(
                        "Nothing was recorded. Check that the stream is live right now."
                    )
                }

                var saved = 0
                for (f in files) {
                    if (saveToMediaStore(f)) saved++
                }
                "Done. Saved $saved recording(s) in the MediaSaver folder (Movies)."
            } catch (e: Throwable) {
                friendlyError(e)
            } finally {
                outDir.deleteRecursively()
            }
            liveActive = false
            runOnUiThread {
                stopBtn.visibility = View.GONE
                stopService(Intent(this, RecordingService::class.java))
                setBusy(false, message)
            }
        }
    }

    private fun downloadPhotos(urls: List<String>, referer: String, ua: String, cookies: String) {
        if (urls.isEmpty()) {
            setBusy(false, "No photos were found on that page. Scroll the page so the photos load, then tap Save photos.")
            return
        }
        setBusy(true, "Saving ${urls.size} photo(s)...")
        thread {
            var saved = 0
            var skipped = 0
            var lastError = ""
            val outDir = File(cacheDir, "photos")
            outDir.mkdirs()
            for ((i, address) in urls.withIndex()) {
                try {
                    val c = URL(address).openConnection() as HttpURLConnection
                    c.connectTimeout = 15000
                    c.readTimeout = 30000
                    c.instanceFollowRedirects = true
                    if (ua.isNotEmpty()) c.setRequestProperty("User-Agent", ua)
                    if (referer.isNotEmpty()) c.setRequestProperty("Referer", referer)
                    if (cookies.isNotEmpty()) c.setRequestProperty("Cookie", cookies)
                    val code = c.responseCode
                    if (code !in 200..299) {
                        lastError = "HTTP $code"
                        skipped++
                        c.disconnect()
                        continue
                    }
                    val bytes = c.inputStream.use { it.readBytes() }
                    c.disconnect()
                    if (bytes.size < 15000) {
                        skipped++
                        continue
                    }
                    val ext = when {
                        bytes.size > 4 && bytes[0] == 0xFF.toByte() && bytes[1] == 0xD8.toByte() -> "jpg"
                        bytes.size > 4 && bytes[0] == 0x89.toByte() && bytes[1] == 0x50.toByte() -> "png"
                        bytes.size > 12 && String(bytes, 8, 4, Charsets.ISO_8859_1) == "WEBP" -> "webp"
                        bytes.size > 4 && bytes[0] == 0x47.toByte() && bytes[1] == 0x49.toByte() -> "gif"
                        else -> "jpg"
                    }
                    val f = File(outDir, "photo_" + System.currentTimeMillis() + "_" + i + "." + ext)
                    f.writeBytes(bytes)
                    if (saveToMediaStore(f)) saved++
                    f.delete()
                } catch (e: Throwable) {
                    lastError = e.message ?: "error"
                    skipped++
                }
            }
            outDir.deleteRecursively()
            val msg = if (saved > 0) {
                "Done. Saved $saved photo(s) in Pictures/MediaSaver." +
                    (if (skipped > 0) " Skipped $skipped small or failed image(s)." else "")
            } else {
                "No photos were saved ($skipped skipped${if (lastError.isNotEmpty()) ", last: $lastError" else ""})."
            }
            runOnUiThread { setBusy(false, msg) }
        }
    }

    private fun saveRecorded(f: File) {
        setBusy(true, "Saving the recording...")
        Thread {
            val msg = try {
                if (saveToMediaStore(f)) {
                    "Done. Saved the recording in Movies/MediaSaver. If it does not play in your gallery, open it with VLC or MX Player."
                } else {
                    "Could not save the file."
                }
            } catch (e: Throwable) {
                friendlyError(e)
            }
            f.delete()
            runOnUiThread { setBusy(false, msg) }
        }.start()
    }

    private fun startCaptured(
        media: String,
        referer: String,
        ua: String,
        cookies: String,
        headers: List<String>
    ) {
        if (liveActive) return
        val minutes = (liveMinutes.text.toString().toIntOrNull() ?: 60).coerceIn(1, 360)
        liveActive = true

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            askNotifications.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        ContextCompat.startForegroundService(this, Intent(this, RecordingService::class.java))

        stopBtn.isEnabled = true
        stopBtn.visibility = View.VISIBLE
        setBusy(
            true,
            "Recording from the page... it stops when the stream ends, after $minutes minutes, or when you tap Stop."
        )

        thread {
            initThread?.join()
            val outDir = File(cacheDir, "web")
            val message: String = try {
                if (!engineReady) {
                    throw IllegalStateException("Engine failed to start: ${engineError ?: "unknown error"}")
                }
                outDir.deleteRecursively()
                outDir.mkdirs()

                val request = YoutubeDLRequest(media)
                request.addOption("-o", outDir.absolutePath + "/web_%(epoch)s_%(autonumber)s.%(ext)s")
                request.addOption("--no-mtime")
                request.addOption("--no-part")
                if (referer.isNotBlank()) request.addOption("--referer", referer)
                if (ua.isNotBlank()) request.addOption("--user-agent", ua)
                for (h in headers) request.addOption("--add-header", h)

                // Give the page's login cookies to the downloader as a cookie file
                if (cookies.isNotBlank()) {
                    val host = try {
                        URL(media).host
                    } catch (e: Exception) {
                        ""
                    }
                    if (host.isNotBlank()) {
                        val jar = File(cacheDir, "web_cookies.txt")
                        val sb = StringBuilder("# Netscape HTTP Cookie File\n")
                        for (part in cookies.split(";")) {
                            val kv = part.trim()
                            val i = kv.indexOf('=')
                            if (i > 0) {
                                sb.append(host).append("\tFALSE\t/\tFALSE\t2147483647\t")
                                    .append(kv.substring(0, i)).append("\t")
                                    .append(kv.substring(i + 1)).append("\n")
                            }
                        }
                        jar.writeText(sb.toString())
                        request.addOption("--cookies", jar.absolutePath)
                    }
                }

                val low = media.lowercase()
                val streaming = low.contains(".m3u8") || low.contains(".flv") || low.contains(".mpd")
                if (streaming) {
                    request.addOption("--downloader", "ffmpeg")
                    request.addOption("--hls-use-mpegts")
                    request.addOption("--downloader-args", "ffmpeg_i:-reconnect 1 -reconnect_streamed 1 -reconnect_at_eof 1 -reconnect_delay_max 10 -rw_timeout 30000000 ffmpeg:-t " + (minutes * 60))
                }

                var failure: Throwable? = null
                try {
                    YoutubeDL.getInstance().execute(request, "live")
                } catch (e: Throwable) {
                    failure = e
                }

                val files = (outDir.listFiles() ?: emptyArray<File>())
                    .filter { it.isFile && it.length() > 0 }
                    .map { fixExtension(it) }
                    .sortedBy { it.name }

                if (files.isEmpty()) {
                    throw failure ?: IllegalStateException("Nothing was recorded from that page.")
                }

                var saved = 0
                for (f in files) {
                    if (saveToMediaStore(f)) saved++
                }
                "Done. Saved $saved file(s) in the MediaSaver folder (Movies)."
            } catch (e: Throwable) {
                friendlyError(e)
            } finally {
                outDir.deleteRecursively()
            }
            liveActive = false
            runOnUiThread {
                stopBtn.visibility = View.GONE
                stopService(Intent(this, RecordingService::class.java))
                setBusy(false, message)
            }
        }
    }

    private fun startDownload() {
        // Sites the downloader engine doesn't know (Tango) always go through the page opener
        val typed = extractUrl(urlInput.text.toString())
        if (!webTab && typed != null && typed.lowercase().contains("tango.me")) {
            selectTab(true)
        }
        if (webTab) {
            val pageLink = extractUrl(urlInput.text.toString())
            if (pageLink == null) {
                Toast.makeText(this, "Paste the page link first", Toast.LENGTH_SHORT).show()
                return
            }
            if (liveActive) return
            val intent = Intent(this, BrowserActivity::class.java)
            intent.putExtra("url", pageLink)
            intent.putExtra("photos", webModeGroup.checkedRadioButtonId == R.id.webPhoto)
            browserLauncher.launch(intent)
            return
        }
        if (modeGroup.checkedRadioButtonId == R.id.modeLive) {
            startLive()
            return
        }
        if (modeGroup.checkedRadioButtonId == R.id.modeSnap) {
            startSnapDownload(urlInput.text.toString())
            return
        }
        val url = extractUrl(urlInput.text.toString())
        if (url == null) {
            Toast.makeText(this, "Paste a valid link first", Toast.LENGTH_SHORT).show()
            return
        }
        val mode = when (modeGroup.checkedRadioButtonId) {
            R.id.modeAudio -> "audio"
            R.id.modeVideo -> "video"
            else -> "auto"
        }
        setBusy(true, "Downloading... keep the app open.")

        thread {
            initThread?.join()
            val outDir = File(cacheDir, "dl")
            val message: String = try {
                if (!engineReady) {
                    throw IllegalStateException("Engine failed to start: ${engineError ?: "unknown error"}")
                }
                outDir.deleteRecursively()
                outDir.mkdirs()

                val cookies = File(filesDir, "cookies.txt")
                val template = outDir.absolutePath + "/%(id)s.%(ext)s"

                // Pass 1: videos / reels / audio
                val request = YoutubeDLRequest(url)
                request.addOption("-o", template)
                request.addOption("--no-mtime")
                request.addOption("--playlist-end", "50")
                if (mode == "audio") {
                    request.addOption("-f", "bestaudio[ext=m4a]/bestaudio/best")
                } else {
                    // Highest resolution first (then H.264 so it plays everywhere), best audio merged in
                    request.addOption("-f", "bv*+ba/b")
                    request.addOption("-S", "res,vcodec:h264,br,acodec:aac")
                    request.addOption("--merge-output-format", "mp4")
                }
                if (cookies.exists()) {
                    request.addOption("--cookies", cookies.absolutePath)
                }

                var failure: Throwable? = null
                try {
                    YoutubeDL.getInstance().execute(request)
                } catch (e: Throwable) {
                    failure = e
                }

                // Pass 2: photo posts have no video, so save their image instead
                if (failure != null && mode != "audio") {
                    try {
                        val photoRequest = YoutubeDLRequest(url)
                        photoRequest.addOption("-o", template)
                        photoRequest.addOption("--no-mtime")
                        photoRequest.addOption("--playlist-end", "50")
                        photoRequest.addOption("--skip-download")
                        photoRequest.addOption("--write-thumbnail")
                        photoRequest.addOption("--ignore-no-formats-error")
                        if (cookies.exists()) {
                            photoRequest.addOption("--cookies", cookies.absolutePath)
                        }
                        YoutubeDL.getInstance().execute(photoRequest)
                    } catch (e: Throwable) {
                        // keep whatever was saved; the first error is reported if nothing was
                    }
                }

                val imageExts = setOf("jpg", "jpeg", "png", "webp")
                val all = (outDir.listFiles() ?: emptyArray<File>())
                    .filter { it.isFile && !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") }
                // Drop preview images of videos that were already downloaded
                val videoStems = all
                    .filter { it.extension.lowercase() !in imageExts }
                    .map { it.nameWithoutExtension }
                    .toSet()
                val files = all
                    .filter { it.extension.lowercase() !in imageExts || it.nameWithoutExtension !in videoStems }
                    .sortedBy { it.name }

                if (files.isEmpty()) {
                    throw failure ?: IllegalStateException("Nothing was downloaded.")
                }

                var saved = 0
                for (f in files) {
                    if (saveToMediaStore(f)) saved++
                }
                "Done. Saved $saved file(s) in the MediaSaver folder (Pictures / Movies / Music)."
            } catch (e: Throwable) {
                friendlyError(e)
            } finally {
                outDir.deleteRecursively()
            }
            runOnUiThread { setBusy(false, message) }
        }
    }

    private fun friendlyError(e: Throwable): String {
        val raw = (e.message ?: e.toString()).trim()
        // Keep only the lines that matter: drop warnings and ffmpeg playlist chatter
        val lines = raw.lines().map { it.trim() }.filter { it.isNotEmpty() }
        val important = lines.filter {
            val l = it.lowercase()
            !l.startsWith("warning:") && !l.startsWith("[hls @") && !l.startsWith("[tiktok:live] the extractor")
        }
        val errLines = important.filter {
            val l = it.lowercase()
            l.contains("error") || l.contains("failed") || l.contains("unable") || l.contains("not ")
        }
        val core = (if (errLines.isNotEmpty()) errLines else important).takeLast(4).joinToString("\n")
        val low = core.lowercase()
        val hint = when {
            "http error 401" in low || "401 unauthorized" in low || "unauthorized" in low ||
                "http error 403" in low || "403 forbidden" in low || "forbidden" in low ->
                "The site refused access. In Other websites, log in inside the page first, press play, wait a few seconds until Start turns on, then tap Start."
            "http error 429" in low || "too many requests" in low ->
                "The site is limiting requests. Wait a few minutes and try again."
            "unsupported url" in low ->
                "The app doesn't support this site directly. Open the Other websites tab, paste the link there and tap Open page."
            "not currently live" in low || "isn't live" in low || "is offline" in low ||
                "user is not live" in low || "ended" in low ->
                "This account is not live right now, or the live has ended. Start again when the stream is on."
            "login" in low || "cookies" in low || "private" in low || "empty media response" in low ->
                "This content needs a logged-in session. Tap Import login cookies."
            else -> "If this keeps happening, tap Update engine and try again."
        }
        val short = if (core.length > 400) core.takeLast(400) else core
        return "Failed: $short\n\n$hint"
    }

    private fun saveToMediaStore(file: File): Boolean {
        val ext = file.extension.lowercase()
        val mime = if (ext == "ts") {
            "video/mp2t"
        } else {
            MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
        }

        val target = when {
            mime.startsWith("image/") ->
                MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) to
                    Environment.DIRECTORY_PICTURES
            mime.startsWith("video/") ->
                MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) to
                    Environment.DIRECTORY_MOVIES
            mime.startsWith("audio/") ->
                MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) to
                    Environment.DIRECTORY_MUSIC
            else ->
                MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY) to
                    Environment.DIRECTORY_DOWNLOADS
        }

        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, target.second + "/MediaSaver")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }

        val uri = contentResolver.insert(target.first, values) ?: return false
        val out = contentResolver.openOutputStream(uri) ?: return false
        out.use { o -> file.inputStream().use { it.copyTo(o) } }

        val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
        contentResolver.update(uri, done, null, null)
        return true
    }

    private fun updateEngine() {
        setBusy(true, "Updating engine...")
        thread {
            initThread?.join()
            val message = try {
                val result = YoutubeDL.getInstance().updateYoutubeDL(applicationContext)
                "Engine update finished: ${result ?: "done"}"
            } catch (e: Throwable) {
                "Update failed: ${e.message ?: e.toString()}"
            }
            runOnUiThread { setBusy(false, message) }
        }
    }

    private fun importCookies(uri: Uri) {
        try {
            val input = contentResolver.openInputStream(uri)
                ?: throw IllegalStateException("Could not open that file.")
            input.use { i ->
                File(filesDir, "cookies.txt").outputStream().use { o -> i.copyTo(o) }
            }
            status.text = "Login cookies imported. Stories and logged-in content can now work."
        } catch (e: Throwable) {
            status.text = "Could not import cookies: ${e.message ?: e.toString()}"
        }
    }
}
