package com.khalid.mediasaver

/** Finds live/video stream addresses (m3u8 / flv) inside page text or JSON. */
object StreamFinder {

    private val urlRegex = Regex("https?://[^\"'\\\\\\s<>]+?\\.(?:flv|m3u8)[^\"'\\\\\\s<>]*")
    private val roomRegex = Regex("\"(?:roomId|room_id)\"\\s*:\\s*\"?(\\d{6,})")

    /** Undo the JSON / HTML escaping TikTok uses around URLs. */
    fun clean(text: String): String = text
        .replace("\\\\u0026", "&").replace("\\u0026", "&")
        .replace("\\\\u002F", "/").replace("\\u002F", "/")
        .replace("\\\\/", "/").replace("\\/", "/")
        .replace("&amp;", "&")

    fun urls(text: String): List<String> =
        urlRegex.findAll(clean(text)).map { it.value }.toList().distinct()

    fun roomId(text: String): String? {
        val id = roomRegex.find(text)?.groupValues?.get(1) ?: return null
        return if (id.trim('0').isEmpty()) null else id
    }

    /** HLS first (safe to stop any time), then the original-quality stream. */
    fun best(found: List<String>): String? = ordered(found).firstOrNull()

    fun ordered(found: List<String>): List<String> = found.distinct().sortedByDescending { score(it) }

    private val qualityRegex = Regex("_(uhd|hd|sd|ld|ao)(?=[._/?])")

    private fun score(u: String): Int {
        val l = u.lowercase()
        var s = 0
        if (l.contains(".m3u8")) s += 100
        if (l.contains("_or4") || l.contains("origin")) s += 30
        s += when (qualityRegex.find(l)?.groupValues?.get(1)) {
            null -> 25
            "uhd" -> 20
            "hd" -> 15
            "sd" -> 5
            "ld" -> 0
            else -> -200
        }
        if (l.contains("only_audio") || l.contains("audio_only")) s -= 200
        return s
    }

    const val UA =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"

    fun httpGet(address: String, cookie: String, ua: String): Pair<Int, String> {
        val c = java.net.URL(address).openConnection() as java.net.HttpURLConnection
        c.setRequestProperty("User-Agent", ua)
        c.setRequestProperty("Accept", "application/json, text/plain, */*")
        c.setRequestProperty("Accept-Language", "en-US,en;q=0.9")
        c.setRequestProperty("Referer", "https://www.tiktok.com/")
        if (cookie.isNotEmpty()) c.setRequestProperty("Cookie", cookie)
        c.connectTimeout = 15000
        c.readTimeout = 25000
        c.instanceFollowRedirects = true
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val body = stream?.bufferedReader()?.use { it.readText() } ?: ""
        c.disconnect()
        return Pair(code, body)
    }

    class Lookup(val candidates: List<String>, val note: String)

    /**
     * Finds TikTok live stream addresses without the page's player:
     * 1) TikTok's live-room API, 2) the webcast room info API, 3) the public live page.
     */
    fun tiktokLookup(link: String, cookie: String, ua: String): Lookup {
        val notes = ArrayList<String>()
        try {
            val userRegex = Regex("tiktok\\.com/@([^/?#]+)")
            val roomInUrl = Regex("room_id=(\\d{6,})")
            var user = userRegex.find(link)?.groupValues?.get(1)
            var roomId: String? = roomInUrl.find(link)?.groupValues?.get(1)
            if (user == null) {
                val c = java.net.URL(link).openConnection() as java.net.HttpURLConnection
                c.setRequestProperty("User-Agent", ua)
                c.connectTimeout = 15000
                c.readTimeout = 20000
                c.instanceFollowRedirects = true
                c.responseCode
                val finalUrl = c.url.toString()
                c.disconnect()
                user = userRegex.find(finalUrl)?.groupValues?.get(1)
                if (roomId == null) roomId = roomInUrl.find(finalUrl)?.groupValues?.get(1)
            }
            if (cookie.isNotEmpty()) notes.add("with cookies")

            if (user != null) {
                notes.add("@$user")
                try {
                    val r = httpGet(
                        "https://www.tiktok.com/api-live/user/room/?aid=1988&sourceType=54&uniqueId=" +
                            java.net.URLEncoder.encode(user, "UTF-8"),
                        cookie, ua
                    )
                    notes.add("room API " + r.first)
                    val found = urls(r.second)
                    if (found.isNotEmpty()) return Lookup(ordered(found), notes.joinToString(", "))
                    if (roomId == null) roomId = roomId(r.second)
                } catch (e: Throwable) {
                    notes.add("room API failed: " + (e.message ?: "error"))
                }
            } else {
                notes.add("no username in link")
            }

            if (roomId != null) {
                try {
                    val r = httpGet("https://webcast.tiktok.com/webcast/room/info/?aid=1988&room_id=$roomId", cookie, ua)
                    notes.add("room info " + r.first)
                    val found = urls(r.second)
                    if (found.isNotEmpty()) return Lookup(ordered(found), notes.joinToString(", "))
                } catch (e: Throwable) {
                    notes.add("room info failed: " + (e.message ?: "error"))
                }
            } else {
                notes.add("no room id")
            }

            if (user != null) {
                try {
                    val r = httpGet("https://www.tiktok.com/@$user/live", cookie, ua)
                    notes.add("live page " + r.first + " " + (r.second.length / 1024) + "KB")
                    val found = urls(r.second)
                    if (found.isNotEmpty()) return Lookup(ordered(found), notes.joinToString(", "))
                } catch (e: Throwable) {
                    notes.add("live page failed: " + (e.message ?: "error"))
                }
            }
        } catch (e: Throwable) {
            notes.add("lookup failed: " + (e.message ?: "error"))
        }
        return Lookup(emptyList(), notes.joinToString(", ") + ", no stream address")
    }

    /** Tries the candidates best-first and returns the first one the server actually serves. */
    fun firstWorking(list: List<String>, ua: String, referer: String): Pair<String?, String> {
        val tried = ArrayList<String>()
        for (u in list.take(8)) {
            try {
                val c = java.net.URL(u).openConnection() as java.net.HttpURLConnection
                c.setRequestProperty("User-Agent", ua)
                c.setRequestProperty("Referer", referer)
                c.connectTimeout = 10000
                c.readTimeout = 10000
                c.instanceFollowRedirects = true
                val code = c.responseCode
                c.disconnect()
                val tag = if (u.lowercase().contains(".m3u8")) "hls" else "flv"
                tried.add("$tag $code")
                if (code in 200..299) return Pair(u, "tried " + tried.joinToString("/"))
            } catch (e: Throwable) {
                tried.add("error")
            }
        }
        return Pair(null, "tried " + tried.size + " stream(s): " + tried.joinToString("/"))
    }
}
