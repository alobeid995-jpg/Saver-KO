package com.khalid.mediasaver

import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

/**
 * Records a live stream straight to a file, without the downloader engine.
 * FLV / continuous streams are copied byte by byte; HLS (m3u8) is followed piece by piece.
 */
class NativeRecorder(
    private val ua: String,
    private val referer: String,
    private val cookie: String,
    private val extraHeaders: List<String>
) {
    @Volatile var stopped = false
        private set
    @Volatile private var conn: HttpURLConnection? = null

    fun stop() {
        stopped = true
        try {
            conn?.disconnect()
        } catch (e: Throwable) {
            // ignore
        }
    }

    private fun open(address: String, readTimeout: Int): HttpURLConnection {
        val c = URL(address).openConnection() as HttpURLConnection
        c.setRequestProperty("User-Agent", ua)
        if (referer.isNotEmpty()) c.setRequestProperty("Referer", referer)
        if (cookie.isNotEmpty()) c.setRequestProperty("Cookie", cookie)
        for (h in extraHeaders) {
            val i = h.indexOf(':')
            if (i > 0) c.setRequestProperty(h.substring(0, i).trim(), h.substring(i + 1).trim())
        }
        c.connectTimeout = 15000
        c.readTimeout = readTimeout
        c.instanceFollowRedirects = true
        conn = c
        return c
    }

    /** Returns null when it finished normally (stopped or stream ended), or an error text. */
    fun record(address: String, out: File): String? =
        if (address.lowercase().contains(".m3u8")) recordHls(address, out) else recordStream(address, out)

    private fun recordStream(address: String, out: File): String? {
        var written = 0L
        var o: FileOutputStream? = null
        try {
            val c = open(address, 30000)
            val code = c.responseCode
            if (code !in 200..299) {
                c.disconnect()
                return "The stream server answered HTTP $code"
            }
            val inp = c.inputStream
            o = FileOutputStream(out)
            val buf = ByteArray(64 * 1024)
            while (!stopped) {
                val n = inp.read(buf)
                if (n < 0) break
                o.write(buf, 0, n)
                written += n
            }
            try {
                inp.close()
            } catch (e: Throwable) {
                // ignore
            }
            c.disconnect()
        } catch (e: Throwable) {
            if (!stopped && written == 0L) return "Stream error: " + (e.message ?: e.toString())
        } finally {
            try {
                o?.close()
            } catch (e: Throwable) {
                // ignore
            }
        }
        return null
    }

    private fun fetchBytes(address: String): ByteArray? {
        return try {
            val c = open(address, 20000)
            val code = c.responseCode
            if (code !in 200..299) {
                c.disconnect()
                null
            } else {
                val inp = c.inputStream
                val b = inp.readBytes()
                inp.close()
                c.disconnect()
                b
            }
        } catch (e: Throwable) {
            null
        }
    }

    private fun resolve(base: String, ref: String): String = URL(URL(base), ref).toString()

    private fun sleepQuiet(ms: Long) {
        try {
            Thread.sleep(ms)
        } catch (e: InterruptedException) {
            // ignore
        }
    }

    private fun recordHls(address: String, out: File): String? {
        var playlist = address
        val seen = HashSet<String>()
        var initWritten = false
        var idle = 0
        var failures = 0
        var anyData = false
        val o = FileOutputStream(out)
        try {
            while (!stopped) {
                val bytes = fetchBytes(playlist)
                if (bytes == null) {
                    failures += 1
                    if (failures > 10) break
                    sleepQuiet(2000)
                    continue
                }
                failures = 0
                val lines = String(bytes, Charsets.UTF_8).lines().map { it.trim() }

                if (lines.any { it.startsWith("#EXT-X-STREAM-INF") }) {
                    // Master playlist: follow the highest-quality variant
                    var bestBw = -1L
                    var bestUri: String? = null
                    for (i in lines.indices) {
                        val l = lines[i]
                        if (l.startsWith("#EXT-X-STREAM-INF")) {
                            val bw = Regex("BANDWIDTH=(\\d+)").find(l)?.groupValues?.get(1)?.toLongOrNull() ?: 0L
                            val uri = lines.drop(i + 1).firstOrNull { it.isNotEmpty() && !it.startsWith("#") }
                            if (uri != null && bw > bestBw) {
                                bestBw = bw
                                bestUri = uri
                            }
                        }
                    }
                    val chosen = bestUri ?: break
                    playlist = resolve(playlist, chosen)
                    continue
                }

                var newOnes = 0
                for (l in lines) {
                    if (stopped) break
                    if (l.startsWith("#EXT-X-MAP") && !initWritten) {
                        val uri = Regex("URI=\"([^\"]+)\"").find(l)?.groupValues?.get(1)
                        if (uri != null) {
                            val b = fetchBytes(resolve(playlist, uri))
                            if (b != null) {
                                o.write(b)
                                initWritten = true
                            }
                        }
                    } else if (l.isNotEmpty() && !l.startsWith("#")) {
                        val seg = resolve(playlist, l)
                        if (seen.add(seg)) {
                            val b = fetchBytes(seg)
                            if (b != null) {
                                o.write(b)
                                o.flush()
                                newOnes += 1
                                anyData = true
                            }
                        }
                    }
                }
                if (lines.any { it.startsWith("#EXT-X-ENDLIST") }) break
                if (newOnes == 0) idle += 1 else idle = 0
                if (idle > 20) break // about 40 seconds with nothing new: the live has ended
                sleepQuiet(2000)
            }
        } catch (e: Throwable) {
            if (!anyData && !stopped) return "Stream error: " + (e.message ?: e.toString())
        } finally {
            try {
                o.close()
            } catch (e: Throwable) {
                // ignore
            }
        }
        if (!anyData && !stopped) return "No video pieces could be downloaded from the live playlist"
        return null
    }
}
